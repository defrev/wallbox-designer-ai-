"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Eye, Cpu, Search, Target } from "lucide-react"

interface ImageAnalysisResult {
  step: number
  confidence: number
  detectedElements: string[]
  ocrText: string[]
  colors: string[]
  objects: string[]
}

interface AdvancedImageRecognitionProps {
  image: File
  onAnalysisComplete: (result: ImageAnalysisResult) => void
}

export function AdvancedImageRecognition({ image, onAnalysisComplete }: AdvancedImageRecognitionProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const [analysisResult, setAnalysisResult] = useState<ImageAnalysisResult | null>(null)

  // Erweiterte Erkennungslogik für jeden Installationsschritt
  const recognitionPatterns = {
    1: {
      name: "Demontage / Vorbereitung",
      keywords: ["leer", "wand", "bohrloch", "kabel", "hängend", "entfernt"],
      colors: ["grau", "weiß", "braun"], // Wandfarben
      objects: ["kabel", "loch", "schatten"],
      ocrPatterns: [],
      confidence: 0.85,
    },
    2: {
      name: "Wallbox montiert",
      keywords: ["wallbox", "montiert", "gerät", "rechteckig"],
      colors: ["schwarz", "weiß", "blau"], // Typische Wallbox-Farben
      objects: ["wallbox", "gehäuse", "logo", "display"],
      ocrPatterns: ["kW", "ChargePoint", "ABL", "KEBA", "Mennekes"],
      confidence: 0.9,
    },
    3: {
      name: "Anschlusskasten offen",
      keywords: ["verteiler", "kasten", "offen", "klemmen", "wago"],
      colors: ["rot", "blau", "gelb", "grün", "schwarz"], // Kabelfarben
      objects: ["klemme", "kabel", "schiene", "sicherung"],
      ocrPatterns: ["WAGO", "Phoenix", "Wieland"],
      confidence: 0.88,
    },
    4: {
      name: "Phasenschaltung (DSW)",
      keywords: ["dsw", "schalter", "phase", "ein", "aus"],
      colors: ["rot", "grün"], // Schalter-LEDs
      objects: ["schalter", "taste", "led", "aufkleber"],
      ocrPatterns: ["DSW", "DSW1", "DSW2", "6+7+8", "ON", "OFF", "Phase"],
      confidence: 0.92,
    },
    5: {
      name: "Messungen",
      keywords: ["messgerät", "display", "digital", "messung"],
      colors: ["schwarz", "gelb", "rot"], // Messgerät-Farben
      objects: ["display", "messleitung", "gerät", "zahl"],
      ocrPatterns: ["Ω", "V", "A", "kΩ", "MΩ", "Fluke", "Benning", "Gossen"],
      confidence: 0.89,
    },
    6: {
      name: "Backend-Freischaltung",
      keywords: ["backend", "bildschirm", "app", "portal", "bestätigt"],
      colors: ["blau", "weiß", "grün"], // UI-Farben
      objects: ["bildschirm", "handy", "tablet", "interface"],
      ocrPatterns: ["Backend", "Portal", "Genius", "App", "bestätigt", "Uhrzeit", ":"],
      confidence: 0.87,
    },
    7: {
      name: "Typenschild / Seriennummer",
      keywords: ["typenschild", "schild", "seriennummer", "nahaufnahme"],
      colors: ["silber", "weiß", "schwarz"], // Schildfarben
      objects: ["schild", "text", "barcode", "qr"],
      ocrPatterns: ["S/N", "Serial", "Model", "kW", "Type", "Made in", "CE"],
      confidence: 0.94,
    },
    8: {
      name: "Unterschrift / Abnahmeprotokoll",
      keywords: ["unterschrift", "formular", "dokument", "abnahme"],
      colors: ["weiß", "schwarz", "blau"], // Papier/Tinte
      objects: ["papier", "formular", "unterschrift", "stempel"],
      ocrPatterns: ["Unterschrift", "Name", "Datum", "Abnahme", "Protokoll", "Status"],
      confidence: 0.91,
    },
  }

  // Simuliere erweiterte KI-Analyse
  const analyzeImage = async () => {
    setIsAnalyzing(true)
    setAnalysisProgress(0)

    const analysisSteps = [
      "Bildqualität prüfen...",
      "Objekterkennung läuft...",
      "OCR-Texterkennung...",
      "Farbanalyse...",
      "Muster-Matching...",
      "Konfidenz berechnen...",
      "Ergebnis validieren...",
    ]

    // Simuliere realistische Analyse-Zeit
    for (let i = 0; i < analysisSteps.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 800))
      setAnalysisProgress((i + 1) * (100 / analysisSteps.length))
    }

    // Erweiterte Bildanalyse basierend auf Dateinamen und simulierten Erkennungsmustern
    const fileName = image.name.toLowerCase()
    let bestMatch = { step: 1, confidence: 0.5 }

    // Durchsuche alle Erkennungsmuster
    Object.entries(recognitionPatterns).forEach(([stepNum, pattern]) => {
      let confidence = 0.5

      // Keyword-Matching
      const keywordMatches = pattern.keywords.filter((keyword) => fileName.includes(keyword)).length
      confidence += keywordMatches * 0.15

      // OCR-Pattern-Matching
      const ocrMatches = pattern.ocrPatterns.filter((ocrPattern) => fileName.includes(ocrPattern.toLowerCase())).length
      confidence += ocrMatches * 0.2

      // Spezielle Erkennungslogik
      if (stepNum === "2" && (fileName.includes("wallbox") || fileName.includes("mounted"))) {
        confidence += 0.25
      }
      if (stepNum === "4" && fileName.includes("dsw")) {
        confidence += 0.3
      }
      if (stepNum === "5" && (fileName.includes("mess") || fileName.includes("meter"))) {
        confidence += 0.25
      }
      if (stepNum === "7" && (fileName.includes("serial") || fileName.includes("sn"))) {
        confidence += 0.3
      }

      if (confidence > bestMatch.confidence) {
        bestMatch = { step: Number.parseInt(stepNum), confidence: Math.min(confidence, 0.98) }
      }
    })

    const result: ImageAnalysisResult = {
      step: bestMatch.step,
      confidence: bestMatch.confidence,
      detectedElements: generateDetectedElements(bestMatch.step),
      ocrText: generateOCRText(bestMatch.step),
      colors: recognitionPatterns[bestMatch.step as keyof typeof recognitionPatterns].colors,
      objects: recognitionPatterns[bestMatch.step as keyof typeof recognitionPatterns].objects,
    }

    setAnalysisResult(result)
    setIsAnalyzing(false)
    onAnalysisComplete(result)
  }

  const generateDetectedElements = (step: number): string[] => {
    const elements: Record<number, string[]> = {
      1: ["Freiliegende Kabel", "Bohrlöcher", "Leere Wandfläche"],
      2: ["Wallbox-Gehäuse", "Herstellerlogo", "Ladeanschluss"],
      3: ["Sicherungskasten", "WAGO-Klemmen", "Phasenkabel"],
      4: ["DIP-Schalter", "Schaltplan-Aufkleber", "LED-Anzeigen"],
      5: ["Digital-Display", "Messleitungen", "Messwerte"],
      6: ["Smartphone-Display", "Backend-Interface", "Zeitstempel"],
      7: ["Typenschild", "Seriennummer", "CE-Kennzeichnung"],
      8: ["Unterschriftenfeld", "Formular-Layout", "Datum/Zeit"],
    }
    return elements[step] || []
  }

  const generateOCRText = (step: number): string[] => {
    const ocrTexts: Record<number, string[]> = {
      1: [],
      2: ["22kW", "ChargePoint Pro", "Model: CP-123"],
      3: ["L1", "L2", "L3", "N", "PE"],
      4: ["DSW1: ON", "DSW2: OFF", "Phase 1-3"],
      5: ["230V", "32A", "0.5Ω", "PASS"],
      6: ["Backend OK", "14:32", "Status: Aktiv"],
      7: ["S/N: WB240001", "22kW", "Made in Germany"],
      8: ["Techniker:", "Datum:", "Unterschrift:"],
    }
    return ocrTexts[step] || []
  }

  return (
    <Card className="border-purple-200 bg-purple-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-purple-800">
          <Cpu className="h-5 w-5" />
          Erweiterte KI-Bilderkennung
        </CardTitle>
        <CardDescription className="text-purple-700">
          Fortgeschrittene Analyse mit Objekterkennung, OCR und Muster-Matching
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Bild-Vorschau */}
          <div className="flex items-center gap-4">
            <img
              src={URL.createObjectURL(image) || "/placeholder.svg"}
              alt="Analyse-Bild"
              className="w-20 h-20 object-cover rounded border"
            />
            <div className="flex-1">
              <p className="font-medium">{image.name}</p>
              <p className="text-sm text-gray-600">{(image.size / 1024 / 1024).toFixed(1)} MB</p>
            </div>
            <Button onClick={analyzeImage} disabled={isAnalyzing}>
              <Search className="h-4 w-4 mr-2" />
              {isAnalyzing ? "Analysiere..." : "KI-Analyse starten"}
            </Button>
          </div>

          {/* Analyse-Fortschritt */}
          {isAnalyzing && (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Eye className="h-4 w-4 animate-pulse text-purple-600" />
                <span className="text-sm">KI analysiert Bildinhalt...</span>
              </div>
              <Progress value={analysisProgress} className="h-2" />
            </div>
          )}

          {/* Analyse-Ergebnis */}
          {analysisResult && (
            <div className="space-y-4 p-4 bg-white rounded border border-purple-200">
              <div className="flex items-center justify-between">
                <h4 className="font-medium text-purple-800">Erkennungsergebnis</h4>
                <Badge
                  variant="default"
                  className={`${
                    analysisResult.confidence > 0.8
                      ? "bg-green-600"
                      : analysisResult.confidence > 0.6
                        ? "bg-yellow-600"
                        : "bg-red-600"
                  }`}
                >
                  <Target className="h-3 w-3 mr-1" />
                  {(analysisResult.confidence * 100).toFixed(0)}% Sicher
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h5 className="font-medium text-sm mb-2">Zugeordneter Schritt</h5>
                  <Badge variant="outline" className="mb-2">
                    Schritt {analysisResult.step}:{" "}
                    {recognitionPatterns[analysisResult.step as keyof typeof recognitionPatterns].name}
                  </Badge>
                </div>

                <div>
                  <h5 className="font-medium text-sm mb-2">Erkannte Objekte</h5>
                  <div className="flex flex-wrap gap-1">
                    {analysisResult.detectedElements.map((element, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {element}
                      </Badge>
                    ))}
                  </div>
                </div>

                {analysisResult.ocrText.length > 0 && (
                  <div>
                    <h5 className="font-medium text-sm mb-2">OCR-Text</h5>
                    <div className="flex flex-wrap gap-1">
                      {analysisResult.ocrText.map((text, index) => (
                        <Badge key={index} variant="outline" className="text-xs font-mono">
                          {text}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <h5 className="font-medium text-sm mb-2">Erkannte Farben</h5>
                  <div className="flex gap-2">
                    {analysisResult.colors.map((color, index) => (
                      <div
                        key={index}
                        className="w-6 h-6 rounded border border-gray-300"
                        style={{ backgroundColor: color }}
                        title={color}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Verbesserungsvorschläge */}
              {analysisResult.confidence < 0.8 && (
                <div className="p-3 bg-yellow-50 border border-yellow-200 rounded">
                  <h5 className="font-medium text-yellow-800 mb-1">Verbesserungsvorschläge</h5>
                  <ul className="text-sm text-yellow-700 list-disc list-inside">
                    <li>Bild näher aufnehmen für bessere Texterkennung</li>
                    <li>Bessere Beleuchtung für klarere Objekterkennung</li>
                    <li>Relevante Elemente zentriert fotografieren</li>
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
