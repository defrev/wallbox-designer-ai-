"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, Zap, ImageIcon, FileText, Settings } from "lucide-react"

interface AIProcessorProps {
  isProcessing: boolean
  progress: number
  projectData: any
}

export function AIProcessor({ isProcessing, progress, projectData }: AIProcessorProps) {
  const processingSteps = [
    {
      name: "Bildanalyse",
      description: "Analyse der hochgeladenen Installationsfotos",
      icon: ImageIcon,
      status: progress > 0 ? "completed" : "pending",
    },
    {
      name: "OCR-Verarbeitung",
      description: "Textextraktion aus Messgeräten",
      icon: FileText,
      status: progress > 20 ? "completed" : progress > 0 ? "processing" : "pending",
    },
    {
      name: "Geräteerkennung",
      description: "Identifikation von Wallbox-Modell und Spezifikationen",
      icon: Settings,
      status: progress > 40 ? "completed" : progress > 20 ? "processing" : "pending",
    },
    {
      name: "Layout-Generierung",
      description: "Erstellung der professionellen Dokumentstruktur",
      icon: FileText,
      status: progress > 60 ? "completed" : progress > 40 ? "processing" : "pending",
    },
    {
      name: "Finaler Zusammenbau",
      description: "Kompilierung der vollständigen Dokumentation",
      icon: CheckCircle,
      status: progress > 80 ? "completed" : progress > 60 ? "processing" : "pending",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800 border-green-200"
      case "processing":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-gray-100 text-gray-600 border-gray-200"
    }
  }

  const getStatusIcon = (status: string, IconComponent: any) => {
    if (status === "completed") {
      return <CheckCircle className="h-5 w-5 text-green-600" />
    } else if (status === "processing") {
      return <Clock className="h-5 w-5 text-blue-600 animate-spin" />
    } else {
      return <IconComponent className="h-5 w-5 text-gray-400" />
    }
  }

  return (
    <div className="space-y-6">
      {/* Verarbeitungsübersicht */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            KI-Verarbeitungsmodul
          </CardTitle>
          <CardDescription>Automatisierte Analyse und Dokumentenerstellung läuft</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Gesamtfortschritt</span>
              <span className="text-sm text-gray-600">{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />

            {isProcessing && (
              <div className="flex items-center gap-2 text-sm text-blue-600">
                <Clock className="h-4 w-4 animate-spin" />
                Ihre Dokumentation wird verarbeitet...
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Verarbeitungsschritte */}
      <Card>
        <CardHeader>
          <CardTitle>Verarbeitungsschritte</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {processingSteps.map((step, index) => {
              const IconComponent = step.icon
              return (
                <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
                  <div className="flex-shrink-0">{getStatusIcon(step.status, IconComponent)}</div>
                  <div className="flex-1">
                    <h4 className="font-medium">{step.name}</h4>
                    <p className="text-sm text-gray-600">{step.description}</p>
                  </div>
                  <Badge className={getStatusColor(step.status)}>
                    {step.status === "completed" ? "Fertig" : step.status === "processing" ? "Läuft" : "Wartend"}
                  </Badge>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* KI-Erkenntnisse */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-blue-800">KI-Analyseergebnisse</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-blue-800 mb-3">Erkannte Informationen</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Verarbeitete Bilder:</span>
                  <Badge variant="outline">{projectData.images?.length || 0}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Extrahierter Text:</span>
                  <Badge variant="outline">15 Elemente</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Messwerte:</span>
                  <Badge variant="outline">8 Ablesungen</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Geräteinformationen:</span>
                  <Badge variant="outline">Verifiziert</Badge>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-blue-800 mb-3">Dokumentstruktur</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Deckblatt erstellt
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Technische Spezifikationen
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Installationsfotos organisiert
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Messprotokoll erstellt
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Abnahmeprotokoll bereit
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
