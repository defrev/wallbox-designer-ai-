"use client"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Download, ImageIcon, CheckCircle, Clock, AlertCircle, Camera, FileImage } from "lucide-react"

interface PhotoGeneratorProps {
  projectData: any
  installationSteps: any // Pass the installation steps object
}

export function PhotoGenerator({ projectData, installationSteps }: PhotoGeneratorProps) {
  const [isGenerating, setIsGenerating] = useState(false)
  const [generationProgress, setGenerationProgress] = useState(0)
  const [photosReady, setPhotosReady] = useState(false)
  const [generationError, setGenerationError] = useState<string | null>(null)
  const [generatedPhotos, setGeneratedPhotos] = useState<string[]>([])
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const generatePhotos = async () => {
    setIsGenerating(true)
    setGenerationProgress(0)
    setGenerationError(null)
    setGeneratedPhotos([])

    try {
      const photos: string[] = []
      let pageCounter = 1 // Startet bei Seite 1 für das Deckblatt

      const hasExtraImages = projectData.categorizedImages[10]?.images.length > 0
      const hasMeasurements = projectData.measurements.length > 0
      const dynamicStepsWithImages = Object.values(installationSteps)
        .filter((step: any) => step.step !== 10 && projectData.categorizedImages[step.step]?.images.length > 0)
        .sort((a: any, b: any) => a.step - b.step)

      // Schätzung der Gesamtseiten für den Fortschrittsbalken
      let totalEstimatedPages = 0
      totalEstimatedPages += 1 // Cover page
      totalEstimatedPages += 1 // Technical Specs page
      if (hasExtraImages) totalEstimatedPages += 1 // Extra Images page
      totalEstimatedPages += dynamicStepsWithImages.length // Dynamic steps
      if (hasMeasurements) totalEstimatedPages += 1 // Measurement page
      totalEstimatedPages += 1 // Approval page

      // 1. Deckblatt
      await new Promise((resolve) => setTimeout(resolve, 800))
      const coverPhotoUrl = await drawCoverPhotoOnCanvas(pageCounter, projectData)
      photos.push(coverPhotoUrl)
      setGenerationProgress((pageCounter / totalEstimatedPages) * 100)
      pageCounter++

      // 2. Technische Spezifikationen
      await new Promise((resolve) => setTimeout(resolve, 800))
      const technicalSpecsPhotoUrl = await drawTechnicalSpecsPhotoOnCanvas(pageCounter, projectData)
      photos.push(technicalSpecsPhotoUrl)
      setGenerationProgress((pageCounter / totalEstimatedPages) * 100)
      pageCounter++

      // 3. Extra Bilder (falls vorhanden)
      if (hasExtraImages) {
        await new Promise((resolve) => setTimeout(resolve, 800))
        const extraImagesPhotoUrl = await drawExtraImagesPhotoOnCanvas(pageCounter, projectData)
        photos.push(extraImagesPhotoUrl)
        setGenerationProgress((pageCounter / totalEstimatedPages) * 100)
        pageCounter++
      }

      // 4. Dynamische Seiten für Installationsschritte (1-9)
      for (const stepInfo of dynamicStepsWithImages) {
        await new Promise((resolve) => setTimeout(resolve, 800))
        const stepPhotoUrl = await drawDynamicStepPhotoOnCanvas(stepInfo.name, pageCounter, projectData, stepInfo.step)
        photos.push(stepPhotoUrl)
        setGenerationProgress((pageCounter / totalEstimatedPages) * 100)
        pageCounter++
      }

      // 5. Messprotokoll (falls vorhanden)
      if (hasMeasurements) {
        await new Promise((resolve) => setTimeout(resolve, 800))
        const measurementPhotoUrl = await drawMeasurementPhotoOnCanvas(pageCounter, projectData)
        photos.push(measurementPhotoUrl)
        setGenerationProgress((pageCounter / totalEstimatedPages) * 100)
        pageCounter++
      }

      // 6. Abnahmeprotokoll
      await new Promise((resolve) => setTimeout(resolve, 800))
      const approvalPhotoUrl = await drawApprovalPhotoOnCanvas(pageCounter, projectData)
      photos.push(approvalPhotoUrl)
      setGenerationProgress((pageCounter / totalEstimatedPages) * 100)
      pageCounter++

      setGeneratedPhotos(photos)
      setPhotosReady(true)
    } catch (error) {
      console.error("Fehler bei der Foto-Generierung:", error)
      setGenerationError("Fehler bei der Foto-Generierung. Bitte versuchen Sie es erneut.")
    } finally {
      setIsGenerating(false)
    }
  }

  const getCanvasContext = () => {
    const canvas = canvasRef.current
    if (!canvas) throw new Error("Canvas nicht verfügbar")
    const ctx = canvas.getContext("2d")
    if (!ctx) throw new Error("Canvas Context nicht verfügbar")

    canvas.width = 1200 // Breite
    canvas.height = 675 // Höhe (16:9 Aspektverhältnis)
    ctx.fillStyle = "#ffffff"
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    return { canvas, ctx }
  }

  const convertCanvasToBlobUrl = (canvas: HTMLCanvasElement): Promise<string> => {
    return new Promise((resolve, reject) => {
      canvas.toBlob(
        (blob) => {
          if (blob) {
            const url = URL.createObjectURL(blob)
            resolve(url)
          } else {
            reject(new Error("Failed to create blob from canvas"))
          }
        },
        "image/jpeg",
        0.9,
      )
    })
  }

  const drawCoverPhotoOnCanvas = async (pageNum: number, projectData: any): Promise<string> => {
    const { canvas, ctx } = getCanvasContext()
    let y = 120 // Startpunkt für den Inhalt unter dem Titel

    // Titelbereich
    ctx.fillStyle = "#000000"
    ctx.font = "bold 40px Arial"
    ctx.textAlign = "left"
    ctx.fillText("Deckblatt", 50, 70) // Titel links oben

    ctx.font = "bold 24px Arial"
    ctx.textAlign = "right"
    ctx.fillText(`Seite ${pageNum}`, canvas.width - 50, 70) // Seitenzahl rechts oben

    ctx.textAlign = "left" // Zurücksetzen

    // Logo (Text-basiert)
    ctx.font = "bold 48px Arial"
    ctx.fillStyle = "#ef4444"
    ctx.fillText("GENIUS", 50, y + 60)
    ctx.fillStyle = "#000000"
    ctx.font = "bold 32px Arial"
    ctx.fillText("ELEKTROTECHNIK GmbH", 230, y + 60)
    y += 100

    ctx.font = "bold 36px Arial"
    ctx.fillStyle = "#1f2937"
    ctx.fillText(`Auftragsnummer ${projectData.orderNumber || "O-0000040652"}`, 50, y)
    y += 40
    ctx.font = "bold 28px Arial"
    ctx.fillText("Austausch", 50, y)
    y += 60

    ctx.font = "20px Arial"
    ctx.fillStyle = "#000000"

    ctx.fillText("Kunde :", 50, y)
    ctx.fillText(projectData.customerName || "Henrik Extra", 200, y)
    y += 25
    ctx.fillText(projectData.address || "An der Hühnerhecke 2", 200, y)
    y += 25
    ctx.fillText("63755 Alzenau", 200, y)
    y += 40

    ctx.fillText("Service Partner :", 50, y)
    ctx.fillText(projectData.servicePartner || "GENIUS Elektrotechnik GmbH", 200, y)
    y += 40

    ctx.fillText("Erstellte Technische Protokoll durch :", 50, y)
    ctx.fillText(projectData.technician || "Raghad Ageli", 450, y)
    y += 25

    ctx.fillText("Geprüfte Techniker :", 50, y)
    ctx.fillText(projectData.checkedTechnician || "Naser Ageli", 450, y)
    y += 25

    ctx.fillText(`Datum : ${projectData.date || new Date().toLocaleDateString("de-DE")}`, 50, y)
    y += 40

    ctx.font = "bold 28px Arial"
    ctx.fillStyle = "#16a34a" // Grün
    ctx.fillText("Auftragsstatus : Abgeschlossen", 50, y)

    return convertCanvasToBlobUrl(canvas)
  }

  const drawTechnicalSpecsPhotoOnCanvas = async (pageNum: number, projectData: any): Promise<string> => {
    const { canvas, ctx } = getCanvasContext()
    let y = 120

    ctx.fillStyle = "#000000"
    ctx.font = "bold 40px Arial"
    ctx.textAlign = "left"
    ctx.fillText("Technische Spezifikationen", 50, 70)

    ctx.font = "bold 24px Arial"
    ctx.textAlign = "right"
    ctx.fillText(`Seite ${pageNum}`, canvas.width - 50, 70)

    ctx.textAlign = "left"

    ctx.font = "bold 28px Arial"
    ctx.fillText("Wallbox-Informationen:", 50, y)
    y += 40
    ctx.font = "24px Arial"
    ctx.fillText(`Modell: ${projectData.wallboxModel || "N/A"}`, 70, y)
    y += 30
    ctx.fillText(`Seriennummer: ${projectData.serialNumber || "N/A"}`, 70, y)
    y += 30
    ctx.fillText(`Leistung: ${projectData.power || "N/A"}`, 70, y)
    y += 60

    ctx.font = "bold 28px Arial"
    ctx.fillText("Gerätekonfiguration:", 50, y)
    y += 40
    ctx.font = "24px Arial"
    ctx.fillText(`DIP-Schalter DSW1: ${projectData.toggleSettings?.DSW1 ? "EIN" : "AUS"}`, 70, y)
    y += 30
    ctx.fillText(`DIP-Schalter DSW2: ${projectData.toggleSettings?.DSW2 ? "EIN" : "AUS"}`, 70, y)
    y += 30
    ctx.fillText(`Phase 1: ${projectData.toggleSettings?.Phase1 ? "EIN" : "AUS"}`, 70, y)
    y += 30
    ctx.fillText(`Phase 2: ${projectData.toggleSettings?.Phase2 ? "EIN" : "AUS"}`, 70, y)
    y += 30
    ctx.fillText(`Phase 3: ${projectData.toggleSettings?.Phase3 ? "EIN" : "AUS"}`, 70, y)

    return convertCanvasToBlobUrl(canvas)
  }

  const drawExtraImagesPhotoOnCanvas = async (pageNum: number, projectData: any): Promise<string> => {
    const { canvas, ctx } = getCanvasContext()
    const y = 120

    ctx.fillStyle = "#000000"
    ctx.font = "bold 40px Arial"
    ctx.textAlign = "left"
    ctx.fillText("Extra Bilder", 50, 70)

    ctx.font = "bold 24px Arial"
    ctx.textAlign = "right"
    ctx.fillText(`Seite ${pageNum}`, canvas.width - 50, 70)

    ctx.textAlign = "left"

    const images = projectData.categorizedImages[10]?.images || []
    if (images.length === 0) {
      ctx.font = "24px Arial"
      ctx.fillStyle = "#6b7280"
      ctx.textAlign = "center"
      ctx.fillText("Keine Extra Bilder vorhanden", canvas.width / 2, canvas.height / 2)
      return convertCanvasToBlobUrl(canvas)
    }

    const maxImagesPerRow = 4
    const padding = 20
    const availableWidth = canvas.width - 100
    const imgWidth =
      (availableWidth - (Math.min(images.length, maxImagesPerRow) - 1) * padding) /
      Math.min(images.length, maxImagesPerRow)
    const imgHeight = imgWidth * (9 / 16)

    let currentX = 50
    let currentY = y

    for (let i = 0; i < images.length; i++) {
      const imageFile = images[i]
      const reader = new FileReader()
      reader.readAsDataURL(imageFile)

      await new Promise<void>((resolve) => {
        reader.onload = (e) => {
          const imgData = e.target?.result as string
          const img = new Image()
          img.crossOrigin = "anonymous"
          img.onload = () => {
            if (currentX + imgWidth > canvas.width - 50) {
              currentX = 50
              currentY += imgHeight + padding
            }
            if (currentY + imgHeight > canvas.height - 50) {
              // Content will be cut off if it overflows a single photo page
            }
            ctx.drawImage(img, currentX, currentY, imgWidth, imgHeight)
            currentX += imgWidth + padding
            resolve()
          }
          img.src = imgData
        }
      })
    }
    return convertCanvasToBlobUrl(canvas)
  }

  const drawDynamicStepPhotoOnCanvas = async (
    stepName: string,
    pageNum: number,
    projectData: any,
    stepNum: number,
  ): Promise<string> => {
    const { canvas, ctx } = getCanvasContext()
    let y = 120 // Startpunkt für den Inhalt unter dem Titel

    // Titelbereich
    ctx.fillStyle = "#000000"
    ctx.font = "bold 40px Arial"
    ctx.textAlign = "left"
    ctx.fillText(stepName, 50, 70) // Titel links oben

    ctx.font = "bold 24px Arial"
    ctx.textAlign = "right"
    ctx.fillText(`Seite ${pageNum}`, canvas.width - 50, 70) // Seitenzahl rechts oben

    ctx.textAlign = "left" // Zurücksetzen

    const categorizedStep = projectData.categorizedImages[stepNum]
    if (!categorizedStep || categorizedStep.images.length === 0) {
      ctx.font = "24px Arial"
      ctx.fillStyle = "#6b7280"
      ctx.textAlign = "center"
      ctx.fillText("Keine Bilder für diesen Schritt vorhanden", canvas.width / 2, canvas.height / 2)
      return convertCanvasToBlobUrl(canvas)
    }

    // Zusätzlicher Text für spezifische Schritte (DSW, Backend-Bestätigung)
    if (stepNum === 5 || stepNum === 7) {
      ctx.font = "bold 24px Arial"
      ctx.fillStyle = "#000000"
      ctx.textAlign = "center"
      ctx.fillText(`DSW 1 ${projectData.toggleSettings?.DSW1 ? "ON" : "OFF"}`, canvas.width / 2, y)
      y += 30
      if (stepNum === 5) {
        ctx.fillText(`${projectData.toggleSettings?.DSW1 ? "6+7+8 ON" : "1-5 OFF"}`, canvas.width / 2, y)
        y += 30
      }
      ctx.fillText(`DSW 2 ${projectData.toggleSettings?.DSW2 ? "ON" : "OFF"}`, canvas.width / 2, y)
      y += 30
      if (stepNum === 5) {
        ctx.fillText(`${projectData.toggleSettings?.DSW2 ? "1-8 OFF" : "1-8 OFF"}`, canvas.width / 2, y)
        y += 30
      }
      if (stepNum === 7) {
        ctx.fillStyle = "#16a34a" // Grün
        ctx.fillText(`Bestätigung der Verfügbarkeit im Backend durch Genius GmbH`, canvas.width / 2, y)
        y += 30
        ctx.fillText(
          `Am ${projectData.date} Um ${new Date().toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })} Uhr`,
          canvas.width / 2,
          y,
        )
        y += 30
        ctx.fillStyle = "#000000" // Schwarz zurücksetzen
      }
      ctx.textAlign = "left" // Zurücksetzen
    }

    const images = categorizedStep.images
    const maxImagesPerRow = 4 // Max 4 Bilder pro Reihe
    const padding = 20
    const availableWidth = canvas.width - 100 // 50px padding each side
    const imgWidth =
      (availableWidth - (Math.min(images.length, maxImagesPerRow) - 1) * padding) /
      Math.min(images.length, maxImagesPerRow)
    const imgHeight = imgWidth * (9 / 16) // Annahme: 16:9 Aspektverhältnis

    let currentX = 50
    let currentY = y

    for (let i = 0; i < images.length; i++) {
      const imageFile = images[i]
      const reader = new FileReader()
      reader.readAsDataURL(imageFile)

      await new Promise<void>((resolve) => {
        reader.onload = (e) => {
          const imgData = e.target?.result as string
          const img = new Image()
          img.crossOrigin = "anonymous" // Wichtig für CORS
          img.onload = () => {
            if (currentX + imgWidth > canvas.width - 50) {
              // Neue Reihe
              currentX = 50
              currentY += imgHeight + padding
            }
            if (currentY + imgHeight > canvas.height - 50) {
              // If content overflows, it will be cut off on this single photo page.
              // For multi-page photo output, this would require generating a new photo.
              // For this specific request, we draw what fits.
            }
            ctx.drawImage(img, currentX, currentY, imgWidth, imgHeight)
            currentX += imgWidth + padding
            resolve()
          }
          img.src = imgData
        }
      })
    }
    return convertCanvasToBlobUrl(canvas)
  }

  const drawMeasurementPhotoOnCanvas = async (pageNum: number, projectData: any): Promise<string> => {
    const { canvas, ctx } = getCanvasContext()
    let y = 120

    // Titelbereich
    ctx.fillStyle = "#000000"
    ctx.font = "bold 40px Arial"
    ctx.textAlign = "left"
    ctx.fillText("Messprotokoll", 50, 70)

    ctx.font = "bold 24px Arial"
    ctx.textAlign = "right"
    ctx.fillText(`Seite ${pageNum}`, canvas.width - 50, 70)

    ctx.textAlign = "left"

    ctx.font = "24px Arial"
    ctx.fillStyle = "#1f2937"
    ctx.fillText("Spannung: 230V ✓ OK", 50, y)
    y += 40
    ctx.fillText("Strom: 32A ✓ OK", 50, y)
    y += 40
    ctx.fillText("Widerstand: 0,5Ω ✓ OK", 50, y)
    y += 60
    ctx.fillText("Alle Messwerte innerhalb der Spezifikation", 50, y)

    return convertCanvasToBlobUrl(canvas)
  }

  const drawApprovalPhotoOnCanvas = async (pageNum: number, projectData: any): Promise<string> => {
    const { canvas, ctx } = getCanvasContext()
    let y = 120

    // Titelbereich
    ctx.fillStyle = "#000000"
    ctx.font = "bold 40px Arial"
    ctx.textAlign = "left"
    ctx.fillText("Abnahmeprotokoll", 50, 70)

    ctx.font = "bold 24px Arial"
    ctx.textAlign = "right"
    ctx.fillText(`Seite ${pageNum}`, canvas.width - 50, 70)

    ctx.textAlign = "left"

    ctx.font = "24px Arial"
    ctx.fillStyle = "#16a34a"
    ctx.fillText("✓ Installation erfolgreich abgeschlossen", 50, y)
    y += 40
    ctx.fillStyle = "#000000"
    ctx.fillText(`Abschlussdatum: ${projectData.date}`, 50, y)
    y += 30
    ctx.fillText(`Abschlusszeit: ${new Date().toLocaleTimeString()}`, 50, y)
    y += 50
    ctx.fillText("Techniker-Unterschrift:", 50, y)
    ctx.strokeRect(50, y + 20, 200, 50)

    return convertCanvasToBlobUrl(canvas)
  }

  const downloadPhoto = (photoUrl: string, index: number) => {
    const link = document.createElement("a")
    link.href = photoUrl
    link.download = `Wallbox-Installation-${projectData.customerName || "Kunde"}-Seite-${index + 1}.jpg`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const downloadAllPhotos = () => {
    generatedPhotos.forEach((photoUrl, index) => {
      setTimeout(() => downloadPhoto(photoUrl, index), index * 500)
    })
  }

  return (
    <Card className="border-purple-200 bg-purple-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-purple-800">
          <Camera className="h-5 w-5" />
          Foto-Dokumentgenerierung
        </CardTitle>
        <CardDescription className="text-purple-700">
          Erstellen Sie die Dokumentation als einzelne JPG-Bilder zum einfachen Teilen
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Dokumentstatus */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-3 bg-white rounded border">
              <FileImage className="h-8 w-8 mx-auto mb-2 text-purple-600" />
              <p className="font-medium">Fotos</p>
              <p className="text-2xl font-bold">{generatedPhotos.length}</p>
            </div>
            <div className="text-center p-3 bg-white rounded border">
              <ImageIcon className="h-8 w-8 mx-auto mb-2 text-orange-600" />
              <p className="font-medium">Format</p>
              <p className="text-lg font-bold">JPG</p>
            </div>
            <div className="text-center p-3 bg-white rounded border">
              <CheckCircle className="h-8 w-8 mx-auto mb-2 text-green-600" />
              <p className="font-medium">Qualität</p>
              <p className="text-lg font-bold">HD</p>
            </div>
          </div>

          {/* Generierungsfortschritt */}
          {isGenerating && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 animate-spin text-purple-600" />
                <span className="text-sm font-medium">Fotos werden generiert...</span>
              </div>
              <Progress value={generationProgress} className="h-3" />
              <p className="text-xs text-gray-600">
                {generationProgress < 20
                  ? "Deckblatt wird erstellt..."
                  : generationProgress < 40
                    ? "Technische Daten werden generiert..."
                    : generationProgress < 60
                      ? "Installationsschritte werden dokumentiert..."
                      : generationProgress < 80
                        ? "Messprotokoll wird erstellt..."
                        : "Abnahmeprotokoll wird finalisiert..."}
              </p>
            </div>
          )}

          {/* Fehleranzeige */}
          {generationError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{generationError}</AlertDescription>
            </Alert>
          )}

          {/* Fotos bereit */}
          {photosReady && (
            <Alert className="border-purple-200 bg-purple-50">
              <CheckCircle className="h-4 w-4 text-purple-600" />
              <AlertDescription className="text-purple-800">
                Alle {generatedPhotos.length} Dokumentationsfotos wurden erfolgreich generiert!
              </AlertDescription>
            </Alert>
          )}

          {/* Foto-Vorschau */}
          {generatedPhotos.length > 0 && (
            <div className="space-y-4">
              <h4 className="font-medium">Generierte Fotos:</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {generatedPhotos.map((photoUrl, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={photoUrl || "/placeholder.svg"}
                      alt={`Dokumentation Seite ${index + 1}`}
                      className="w-full aspect-[16/9] object-cover rounded border shadow-sm"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all rounded flex items-center justify-center">
                      <Button
                        onClick={() => downloadPhoto(photoUrl, index)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                        size="sm"
                      >
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    </div>
                    <Badge className="absolute top-2 left-2 bg-purple-600">Seite {index + 1}</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Generierungs-Buttons */}
          <div className="space-y-3">
            <Button
              onClick={generatePhotos}
              disabled={isGenerating}
              className="w-full bg-purple-600 hover:bg-purple-700"
              size="lg"
            >
              <Camera className="h-5 w-5 mr-2" />
              {isGenerating ? "Generiere Fotos..." : "Dokumentation als Fotos erstellen"}
            </Button>

            {photosReady && (
              <Button
                onClick={downloadAllPhotos}
                variant="outline"
                className="w-full bg-transparent border-purple-300"
                size="lg"
              >
                <Download className="h-5 w-5 mr-2" />
                Alle {generatedPhotos.length} Fotos herunterladen
              </Button>
            )}
          </div>

          {/* Foto-Info */}
          <div className="p-4 bg-white rounded border border-purple-200">
            <h4 className="font-medium mb-2">Foto-Dokumentation Inhalt:</h4>
            <ul className="text-sm space-y-1">
              <li>
                📄 <strong>Seite 1:</strong> Deckblatt mit Kundendaten
              </li>
              <li>
                ⚙️ <strong>Seite 2:</strong> Technische Spezifikationen
              </li>
              <li>
                🖼️ <strong>Seite 3:</strong> Extra Bilder (falls vorhanden)
              </li>
              <li>
                📸 <strong>Seite 4+:</strong> Dynamische Installationsschritte mit Bildern
              </li>
              <li>
                📊 <strong>Optional:</strong> Messprotokoll mit Prüfwerten
              </li>
              <li>
                ✅ <strong>Letzte Seite:</strong> Abnahmeprotokoll mit Unterschriften
              </li>
            </ul>
            <div className="mt-3 flex gap-2">
              <Badge variant="outline">Format: JPG</Badge>
              <Badge variant="outline">Auflösung: 1200x675px</Badge>
              <Badge variant="outline">Qualität: 90%</Badge>
            </div>
          </div>
        </div>
      </CardContent>

      {/* Verstecktes Canvas für Foto-Generierung */}
      <canvas ref={canvasRef} style={{ display: "none" }} />
    </Card>
  )
}
