"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Camera, Zap, Settings, FileText, Clock, CheckCircle, ImageIcon, X, Eye, Filter, Search } from "lucide-react"

interface SmartImageCategorizerProps {
  images: File[]
  onCategorizedImagesUpdate: (categorizedImages: CategorizedImages) => void
  onMeasurementsUpdate?: (measurements: any[]) => void // now optional
}

interface CategorizedImages {
  [key: number]: {
    stepName: string
    images: File[]
    confidence: number[]
  }
}

// Definierte Installationsschritte - ALLE 9 Schritte + NEU: Extra Bilder
export const installationSteps = {
  1: {
    name: "Demontage / Vorbereitung",
    icon: Camera,
    description: "Leere Wand ohne Wallbox, sichtbare Bohrlöcher oder alte Kabel",
    color: "bg-gray-500",
    step: 1,
  },
  2: {
    name: "Wallbox montiert",
    icon: Zap,
    description: "Wallbox vollständig an Wand installiert, Logo sichtbar",
    color: "bg-blue-500",
    step: 2,
  },
  3: {
    name: "Offener Anschlusskasten / Verkabelung",
    icon: Settings,
    description: "Geöffneter Sicherungskasten mit sichtbaren Kabeln",
    color: "bg-orange-500",
    step: 3,
  },
  4: {
    name: "Sicherungsbeschriftung",
    icon: FileText,
    description: "LS-Schalter Beschriftungen und Kennzeichnungen",
    color: "bg-red-500",
    step: 4,
  },
  5: {
    name: "Phasenschaltung (DSW-Schalter)",
    icon: Settings,
    description: "DSW-Schalter oder Pläne mit Beschriftung",
    color: "bg-purple-500",
    step: 5,
  },
  6: {
    name: "Messung / Testgerät",
    icon: ImageIcon,
    description: "Digitales Messgerät mit sichtbaren Werten",
    color: "bg-green-500",
    step: 6,
  },
  7: {
    name: "Backend-Freischaltung / Systembestätigung",
    icon: Clock,
    description: "Screenshot von Portal/App mit Bestätigung",
    color: "bg-cyan-500",
    step: 7,
  },
  8: {
    name: "Typenschild / Seriennummer",
    icon: FileText,
    description: "Nahaufnahme Geräteschild mit S/N und Modell",
    color: "bg-indigo-500",
    step: 8,
  },
  9: {
    name: "Abnahmeprotokoll / Unterschrift",
    icon: CheckCircle,
    description: "Ausgefülltes Formular mit Unterschrift",
    color: "bg-emerald-500",
    step: 9,
  },
  10: {
    // NEUE KATEGORIE
    name: "Extra Bilder",
    icon: Camera,
    description: "Manuell zugeordnete Bilder, die keiner spezifischen Kategorie entsprechen",
    color: "bg-gray-400",
    step: 10,
  },
}

export function SmartImageCategorizer({
  images,
  onCategorizedImagesUpdate,
  onMeasurementsUpdate = () => {}, // default
}: SmartImageCategorizerProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisProgress, setAnalysisProgress] = useState(0)
  const [categorizedImages, setCategorizedImages] = useState<CategorizedImages>({})
  const [filteredImages, setFilteredImages] = useState<File[]>([])
  const [analysisComplete, setAnalysisComplete] = useState(false)

  const analyzeAllImages = async () => {
    setIsAnalyzing(true)
    setAnalysisProgress(0)
    setAnalysisComplete(false)

    const newCategorizedImages: CategorizedImages = {}
    const newFilteredImages: File[] = []
    const extractedMeasurements: any[] = [] // Für extrahierte Messwerte

    // Initialisiere ALLE 10 Schritte
    Object.keys(installationSteps).forEach((step) => {
      const stepNum = Number.parseInt(step)
      newCategorizedImages[stepNum] = {
        stepName: installationSteps[stepNum as keyof typeof installationSteps].name,
        images: [],
        confidence: [],
      }
    })

    // Analysiere jedes Bild über den API-Endpunkt
    for (let i = 0; i < images.length; i++) {
      const image = images[i]

      try {
        // Bild in Base64 konvertieren
        const imageBase64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader()
          reader.onloadend = () => resolve(reader.result as string)
          reader.onerror = reject
          reader.readAsDataURL(image)
        })

        // API-Aufruf zur Bildanalyse
        const response = await fetch("/api/analyze-image", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ imageName: image.name, imageBase64 }),
        })

        if (!response.ok) {
          throw new Error(`API error: ${response.statusText}`)
        }

        const result = await response.json()

        // Nur Bilder mit ausreichender Konfidenz kategorisieren
        if (result.confidence > 0.6 && result.step > 0) {
          newCategorizedImages[result.step].images.push(image)
          newCategorizedImages[result.step].confidence.push(result.confidence)

          // Simuliere Messwert-Extraktion für Schritt 6 (Messung / Testgerät)
          if (result.step === 6 && result.ocrText.length > 0) {
            const voltageMatch = result.ocrText.find((text: string) => text.includes("V"))
            const currentMatch = result.ocrText.find((text: string) => text.includes("A"))
            const resistanceMatch = result.ocrText.find((text: string) => text.includes("Ω") || text.includes("kΩ"))

            if (voltageMatch || currentMatch || resistanceMatch) {
              extractedMeasurements.push({
                imageName: image.name,
                voltage: voltageMatch || "N/A",
                current: currentMatch || "N/A",
                resistance: resistanceMatch || "N/A",
              })
            }
          }
        } else {
          // Filtere Bilder mit niedriger Konfidenz oder ohne Zuordnung
          newFilteredImages.push(image)
        }
      } catch (error) {
        console.error(`Fehler bei der Analyse von Bild ${image.name}:`, error)
        newFilteredImages.push(image) // Bei Fehler auch filtern
      }

      setAnalysisProgress(((i + 1) / images.length) * 100)
    }

    setCategorizedImages(newCategorizedImages)
    setFilteredImages(newFilteredImages)
    onCategorizedImagesUpdate(newCategorizedImages)
    onMeasurementsUpdate(extractedMeasurements) // Messwerte aktualisieren
    setIsAnalyzing(false)
    setAnalysisComplete(true)
  }

  const moveImageToStep = (image: File, fromStep: number, toStep: number) => {
    const updated = { ...categorizedImages }

    // Entferne aus altem Schritt
    if (fromStep > 0) {
      const fromIndex = updated[fromStep].images.indexOf(image)
      if (fromIndex > -1) {
        updated[fromStep].images.splice(fromIndex, 1)
        updated[fromStep].confidence.splice(fromIndex, 1)
      }
    } else {
      // Entferne aus gefilterten Bildern
      setFilteredImages((prev) => prev.filter((img) => img !== image))
    }

    // Füge zu neuem Schritt hinzu
    updated[toStep].images.push(image)
    updated[toStep].confidence.push(0.8) // Manuelle Zuordnung = hohe Konfidenz

    setCategorizedImages(updated)
    onCategorizedImagesUpdate(updated)
  }

  const removeImageFromStep = (image: File, step: number) => {
    const updated = { ...categorizedImages }
    const imageIndex = updated[step].images.indexOf(image)

    if (imageIndex > -1) {
      updated[step].images.splice(imageIndex, 1)
      updated[step].confidence.splice(imageIndex, 1)
      setFilteredImages((prev) => [...prev, image]) // Bild in gefilterte Liste verschieben
    }

    setCategorizedImages(updated)
    onCategorizedImagesUpdate(updated)
  }

  const totalCategorized = Object.values(categorizedImages).reduce((sum, step) => sum + step.images.length, 0)
  const completedSteps = Object.values(categorizedImages).filter((step) => step.images.length > 0).length

  return (
    <div className="space-y-6">
      {/* Analyse-Status Box */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <Eye className="h-5 w-5" />
            KI-Bildanalyse & Kategorisierung
          </CardTitle>
          <CardDescription className="text-blue-700">
            Automatische Zuordnung von {images.length} Bildern zu den 10 Installationsschritten
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Statistiken */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-4 bg-white rounded-lg border">
              <div className="flex items-center justify-center mb-2">
                <ImageIcon className="h-6 w-6 text-blue-600" />
              </div>
              <p className="text-sm text-gray-600">Hochgeladen</p>
              <p className="text-2xl font-bold text-blue-600">{images.length}</p>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border">
              <div className="flex items-center justify-center mb-2">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <p className="text-sm text-gray-600">Kategorisiert</p>
              <p className="text-2xl font-bold text-green-600">{totalCategorized}</p>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border">
              <div className="flex items-center justify-center mb-2">
                <Filter className="h-6 w-6 text-orange-600" />
              </div>
              <p className="text-sm text-gray-600">Gefiltert</p>
              <p className="text-2xl font-bold text-orange-600">{filteredImages.length}</p>
            </div>
            <div className="text-center p-4 bg-white rounded-lg border">
              <div className="flex items-center justify-center mb-2">
                <Settings className="h-6 w-6 text-purple-600" />
              </div>
              <p className="text-sm text-gray-600">Schritte</p>
              <p className="text-2xl font-bold">{completedSteps}/10</p>
            </div>
          </div>

          {/* KI-Analyse Status */}
          {isAnalyzing && (
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-2">
                <Search className="h-4 w-4 animate-pulse text-blue-600" />
                <span className="text-sm font-medium">KI analysiert {images.length} Bilder...</span>
              </div>
              <Progress value={analysisProgress} className="h-3" />
              <p className="text-xs text-gray-600">
                {analysisProgress < 25
                  ? "Bildinhalt wird erkannt..."
                  : analysisProgress < 50
                    ? "Installationsschritte werden identifiziert..."
                    : analysisProgress < 75
                      ? "Kategorien werden zugeordnet..."
                      : "Analyse wird abgeschlossen..."}
              </p>
            </div>
          )}

          {/* Analyse-Ergebnis */}
          {analysisComplete && (
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg mb-6">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="font-medium text-green-800">KI-Analyse abgeschlossen</span>
              </div>
              <p className="text-sm text-green-700">
                {totalCategorized} von {images.length} Bildern wurden erfolgreich kategorisiert.
                {filteredImages.length > 0 && ` ${filteredImages.length} Bilder benötigen manuelle Zuordnung.`}
              </p>
            </div>
          )}

          {/* Analyse-Button */}
          <Button onClick={analyzeAllImages} disabled={isAnalyzing || images.length === 0} className="w-full" size="lg">
            <Search className="h-5 w-5 mr-2" />
            {isAnalyzing ? "KI analysiert..." : `${images.length} Bilder mit KI analysieren`}
          </Button>
        </CardContent>
      </Card>

      {/* Alle 10 Installationsschritte - IMMER sichtbar */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Alle Installationsschritte (1-10)</h3>
          <Badge variant="outline" className="text-sm">
            {completedSteps} von 10 Schritten dokumentiert
          </Badge>
        </div>

        {Object.entries(installationSteps).map(([stepNum, stepInfo]) => {
          const step = Number.parseInt(stepNum)
          const stepData = categorizedImages[step] || { stepName: (stepInfo as any).name, images: [], confidence: [] }
          const hasImages = stepData.images.length > 0

          return (
            <Card
              key={step}
              className={`transition-all ${
                hasImages ? "border-green-200 bg-green-50 shadow-md" : "border-gray-200 hover:border-gray-300"
              }`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`p-3 rounded-lg ${hasImages ? (stepInfo as any).color : "bg-gray-100"} text-white transition-colors`}
                  >
                    {(stepInfo as any).icon && (stepInfo as any).icon({ className: "h-5 w-5" })}
                  </div>
                  <div>
                    <h4 className="font-medium text-lg">
                      Schritt {step}: {(stepInfo as any).name}
                    </h4>
                    <p className="text-sm text-gray-600">{(stepInfo as any).description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    variant={hasImages ? "default" : "secondary"}
                    className={hasImages ? "bg-green-600 hover:bg-green-700" : ""}
                  >
                    {stepData.images.length} Bilder
                  </Badge>
                  {hasImages && <CheckCircle className="h-5 w-5 text-green-600" />}
                </div>
              </CardHeader>

              {hasImages && (
                <CardContent className="pt-0">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {stepData.images.map((image, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={URL.createObjectURL(image) || "/placeholder.svg"}
                          alt={`${(stepInfo as any).name} ${index + 1}`}
                          className="w-full aspect-square object-cover rounded border-2 border-green-200"
                        />
                        <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button
                            size="sm"
                            variant="destructive"
                            className="h-6 w-6 p-0"
                            onClick={() => removeImageFromStep(image, step)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                        <Badge className="absolute bottom-1 left-1 text-xs bg-green-600">
                          {Math.round((stepData.confidence[index] || 0) * 100)}%
                        </Badge>
                        <div className="absolute bottom-1 right-1">
                          <p className="text-xs bg-black bg-opacity-70 text-white px-1 rounded">
                            {image.name.substring(0, 6)}...
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              )}

              {!hasImages && analysisComplete && (
                <CardContent className="pt-0">
                  <div className="text-center py-6 text-gray-500">
                    {(stepInfo as any).icon && (stepInfo as any).icon({ className: "h-8 w-8 mx-auto mb-2 opacity-50" })}
                    <p className="text-sm">Keine Bilder für diesen Schritt gefunden</p>
                    <p className="text-xs">Bilder können manuell aus "Gefilterte Bilder" zugeordnet werden</p>
                  </div>
                </CardContent>
              )}
            </Card>
          )
        })}
      </div>

      {/* Gefilterte Bilder */}
      {filteredImages.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <Filter className="h-5 w-5" />
              Gefilterte Bilder ({filteredImages.length})
            </CardTitle>
            <CardDescription className="text-orange-700">
              Diese Bilder konnten nicht automatisch zugeordnet werden und benötigen manuelle Kategorisierung
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {filteredImages.map((image, index) => (
                <div key={index} className="relative group">
                  <img
                    src={URL.createObjectURL(image) || "/placeholder.svg"}
                    alt={`Gefiltert ${index + 1}`}
                    className="w-full aspect-square object-cover rounded border-2 border-orange-200"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all rounded flex items-center justify-center">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                      <select
                        className="text-xs p-2 rounded bg-white border"
                        onChange={(e) => {
                          const toStep = Number.parseInt(e.target.value)
                          if (toStep > 0) {
                            moveImageToStep(image, 0, toStep)
                          }
                        }}
                      >
                        <option value="">Zuordnen zu...</option>
                        {Object.entries(installationSteps).map(([stepNum, stepInfo]) => (
                          <option key={stepNum} value={stepNum}>
                            Schritt {stepNum}: {(stepInfo as any).name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <Badge className="absolute top-1 left-1 text-xs bg-orange-600">Ungefiltert</Badge>
                  <p className="text-xs mt-1 text-gray-600 truncate">{image.name}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Leere Zustand */}
      {!analysisComplete && images.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Search className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">Keine Bilder zum Analysieren</h3>
            <p className="text-gray-500">Laden Sie zuerst Bilder hoch, um die KI-Kategorisierung zu starten</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
