"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { FileText, Edit, Eye, CheckCircle, Calendar, User, MapPin } from "lucide-react"
import { PDFGenerator } from "./pdf-generator"
import { PhotoGenerator } from "./photo-generator"

interface DocumentPreviewProps {
  projectData: any
  isGenerated: boolean
  installationSteps: any // Pass the installation steps object
}

export function DocumentPreview({ projectData, isGenerated, installationSteps }: DocumentPreviewProps) {
  if (!isGenerated) {
    return (
      <div className="text-center py-12">
        <FileText className="h-16 w-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-600 mb-2">Noch kein Dokument erstellt</h3>
        <p className="text-gray-500">
          Vervollständigen Sie die Upload- und Verarbeitungsschritte, um Ihre Dokumentation zu erstellen.
        </p>
      </div>
    )
  }

  // Filter installationSteps to only show steps for which images were categorized (excluding step 10 for now)
  const dynamicStepsWithImages = Object.values(installationSteps)
    .filter((step: any) => step.step !== 10 && projectData.categorizedImages[step.step]?.images.length > 0)
    .sort((a: any, b: any) => a.step - b.step) // Ensure order by step number

  const hasExtraImages = projectData.categorizedImages[10]?.images.length > 0
  const hasMeasurements = projectData.measurements.length > 0

  // Calculate total pages for display in sidebar
  let totalPages = 0
  totalPages += 1 // Cover page (Page 1)
  totalPages += 1 // Technical Specifications (Page 2)
  if (hasExtraImages) totalPages += 1 // Extra Images (Page 3)
  totalPages += dynamicStepsWithImages.length // Pages for categorized steps (from Page 4 or 3)
  if (hasMeasurements) totalPages += 1 // Optional measurement page
  totalPages += 1 // Acceptance protocol page

  let currentPageNumber = 1 // For display in preview

  return (
    <div className="space-y-6">
      {/* Dokumentkopf */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Installationsdokumentation Vorschau
              </CardTitle>
              <CardDescription>Professioneller Wallbox-Installationsbericht - Bereit für Export</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Edit className="h-4 w-4 mr-1" />
                Bearbeiten
              </Button>
              <Button size="sm">
                <Eye className="h-4 w-4 mr-1" />
                Vollansicht
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Dokumentstruktur */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Dokumentseiten */}
        <div className="lg:col-span-2 space-y-4">
          {/* Deckblatt (Page 1) */}
          <Card className="border-2 border-blue-200">
            <CardHeader className="bg-blue-50">
              <CardTitle className="text-lg flex justify-between items-center">
                <span>1. Deckblatt</span>
                <Badge variant="outline">Seite {currentPageNumber++}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="text-center space-y-4">
                {/* Logo-Platzhalter (Text-basiert) */}
                <div className="flex justify-center mb-4">
                  <h2 className="text-4xl font-bold text-red-600">GENIUS</h2>
                  <h2 className="text-2xl font-bold text-gray-900 ml-2 mt-2">ELEKTROTECHNIK GmbH</h2>
                </div>
                <h2 className="text-2xl font-bold">Auftragsnummer {projectData.orderNumber || "O-0000040652"}</h2>
                <h3 className="text-xl font-semibold text-gray-800">Austausch</h3>
                <div className="grid grid-cols-2 gap-4 text-left mt-6">
                  <div>
                    <p className="text-sm text-gray-600">Kunde</p>
                    <p className="font-medium">{projectData.customerName || "Henrik Extra"}</p>
                    <p className="text-sm text-gray-600">
                      {projectData.address || "An der Hühnerhecke 2, 63755 Alzenau"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Service Partner</p>
                    <p className="font-medium">{projectData.servicePartner || "GENIUS Elektrotechnik GmbH"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Erstellte Technische Protokoll durch</p>
                    <p className="font-medium">{projectData.technician || "Raghad Ageli"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Geprüfte Techniker</p>
                    <p className="font-medium">{projectData.checkedTechnician || "Naser Ageli"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Datum</p>
                    <p className="font-medium">{projectData.date}</p>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-gray-50 rounded">
                  <p className="text-sm text-gray-600">Auftragsstatus</p>
                  <p className="text-xl font-bold text-green-600">Abgeschlossen</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Technische Spezifikationen (Page 2) */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex justify-between items-center">
                <span>2. Technische Spezifikationen</span>
                <Badge variant="outline">Seite {currentPageNumber++}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-lg mb-2">Wallbox-Informationen</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">Modell:</p>
                      <p className="font-medium">{projectData.wallboxModel || "N/A"}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Seriennummer:</p>
                      <p className="font-medium">{projectData.serialNumber || "N/A"}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Leistung:</p>
                      <p className="font-medium">{projectData.power || "N/A"}</p>
                    </div>
                  </div>
                </div>
                <Separator />
                <div>
                  <h4 className="font-medium text-lg mb-2">Gerätekonfiguration</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">DIP-Schalter DSW1:</p>
                      <p className="font-medium">{projectData.toggleSettings?.DSW1 ? "EIN" : "AUS"}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">DIP-Schalter DSW2:</p>
                      <p className="font-medium">{projectData.toggleSettings?.DSW2 ? "EIN" : "AUS"}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Phase 1:</p>
                      <p className="font-medium">{projectData.toggleSettings?.Phase1 ? "EIN" : "AUS"}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Phase 2:</p>
                      <p className="font-medium">{projectData.toggleSettings?.Phase2 ? "EIN" : "AUS"}</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Phase 3:</p>
                      <p className="font-medium">{projectData.toggleSettings?.Phase3 ? "EIN" : "AUS"}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Extra Bilder (Page 3, if any) */}
          {hasExtraImages && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex justify-between items-center">
                  <span>3. Extra Bilder</span>
                  <Badge variant="outline">Seite {currentPageNumber++}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {projectData.categorizedImages[10].images.map((image: File, imgIndex: number) => (
                    <div key={imgIndex} className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                      <img
                        src={URL.createObjectURL(image) || "/placeholder.svg"}
                        alt={`Extra Bild ${imgIndex + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Dynamische Installationsschritte (ab Page 4 oder 3) */}
          {dynamicStepsWithImages.map((stepInfo: any, index: number) => {
            const categorizedStep = projectData.categorizedImages[stepInfo.step]
            if (!categorizedStep || categorizedStep.images.length === 0) return null

            // Bestimme den Titel basierend auf dem Schrittnamen und ggf. Wallbox-Modell/Seriennummer
            let pageTitle = stepInfo.name
            if (stepInfo.step === 2 || stepInfo.step === 8) {
              // Wallbox montiert oder Typenschild
              pageTitle = `${projectData.wallboxModel || "Wallbox"} ${projectData.serialNumber || "N/A"}`
            }
            if (stepInfo.step === 3) {
              // Offener Anschlusskasten
              pageTitle = "Installationen" // Wie in Folie 5
            }
            if (stepInfo.step === 4) {
              // Sicherungsbeschriftung
              pageTitle = "Sicherungsbeschriftung"
            }
            if (stepInfo.step === 5) {
              // Phasenschaltung
              pageTitle = "Phasen der Geräteinstallation"
            }
            if (stepInfo.step === 6) {
              // Messung
              pageTitle = "Messungen"
            }
            if (stepInfo.step === 7) {
              // Backend-Freischaltung
              pageTitle = "Betriebsphase"
            }

            return (
              <Card key={stepInfo.step}>
                <CardHeader>
                  <CardTitle className="text-lg flex justify-between items-center">
                    <span>{pageTitle}</span>
                    <Badge variant="outline">Seite {currentPageNumber++}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Zusätzlicher Text für spezifische Schritte */}
                  {(stepInfo.step === 5 || stepInfo.step === 7) && (
                    <div className="mb-4 text-center">
                      <p className="font-bold text-lg">
                        DSW 1 {projectData.toggleSettings?.DSW1 ? "ON" : "OFF"}
                        {stepInfo.step === 5 && ` ${projectData.toggleSettings?.DSW1 ? "6+7+8 ON" : "1-5 OFF"}`}
                      </p>
                      <p className="font-bold text-lg">
                        DSW 2 {projectData.toggleSettings?.DSW2 ? "ON" : "OFF"}
                        {stepInfo.step === 5 && ` ${projectData.toggleSettings?.DSW2 ? "1-8 OFF" : "1-8 OFF"}`}
                      </p>
                      {stepInfo.step === 7 && (
                        <p className="text-green-700 font-semibold">
                          Bestätigung der Verfügbarkeit im Backend durch Genius GmbH
                          <br />
                          Am {projectData.date} Um{" "}
                          {new Date().toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })} Uhr
                        </p>
                      )}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {categorizedStep.images.map((image: File, imgIndex: number) => (
                      <div key={imgIndex} className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                        <img
                          src={URL.createObjectURL(image) || "/placeholder.svg"}
                          alt={`${stepInfo.name} ${imgIndex + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )
          })}

          {/* Messprotokoll (falls vorhanden) */}
          {hasMeasurements && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex justify-between items-center">
                  <span>Messprotokoll</span>
                  <Badge variant="outline">Seite {currentPageNumber++}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-3 border rounded">
                      <p className="text-sm text-gray-600">Spannung</p>
                      <p className="text-xl font-bold text-green-600">230V</p>
                      <Badge variant="outline" className="text-xs">
                        ✓ OK
                      </Badge>
                    </div>
                    <div className="text-center p-3 border rounded">
                      <p className="text-sm text-gray-600">Strom</p>
                      <p className="text-xl font-bold text-green-600">32A</p>
                      <Badge variant="outline" className="text-xs">
                        ✓ OK
                      </Badge>
                    </div>
                    <div className="text-center p-3 border rounded">
                      <p className="text-sm text-gray-600">Widerstand</p>
                      <p className="text-xl font-bold text-green-600">0,5Ω</p>
                      <Badge variant="outline" className="text-xs">
                        ✓ OK
                      </Badge>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-center gap-2 text-green-600">
                    <CheckCircle className="h-5 w-5" />
                    <span className="font-medium">Alle Messwerte innerhalb der Spezifikation</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Abnahme (Letzte Seite) */}
          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="text-lg flex justify-between items-center">
                <span>Installationsabnahme (Abnahmeprotokoll)</span>
                <Badge variant="outline">Seite {currentPageNumber++}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-green-700">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-medium">Installation erfolgreich abgeschlossen</span>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-green-700">Abschlussdatum:</p>
                    <p className="font-medium">{projectData.date}</p>
                  </div>
                  <div>
                    <p className="text-green-700">Abschlusszeit:</p>
                    <p className="font-medium">{new Date().toLocaleTimeString()}</p>
                  </div>
                </div>
                <div className="mt-4 p-3 border border-green-200 rounded bg-white">
                  <p className="text-sm text-green-700 mb-2">Digitale Unterschrift</p>
                  <div className="h-16 bg-green-100 rounded flex items-center justify-center">
                    <span className="text-green-600 font-medium">Techniker-Unterschrift</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Dokumentinfo-Seitenleiste */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Dokumentinformationen</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-600">Erstellt</p>
                  <p className="font-medium">{new Date().toLocaleDateString("de-DE")}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-600">Techniker</p>
                  <p className="font-medium">{projectData.technician || "N/A"}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-600">Standort</p>
                  <p className="font-medium text-xs">{projectData.address || "N/A"}</p>
                </div>
              </div>
              <Separator />
              <div className="space-y-2">
                <p className="text-sm font-medium">Dokumentstatistiken</p>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span>Seiten:</span>
                    <span>{totalPages}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Bilder:</span>
                    <span>{projectData.images?.length || 0}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Format:</span>
                    <span>PDF/JPG</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* PDF Generator */}
          <PDFGenerator projectData={projectData} installationSteps={installationSteps} />

          {/* Photo Generator */}
          <PhotoGenerator projectData={projectData} installationSteps={installationSteps} />
        </div>
      </div>
    </div>
  )
}
