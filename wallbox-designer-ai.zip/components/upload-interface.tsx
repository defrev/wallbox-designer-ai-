"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, Camera, X, AlertTriangle } from "lucide-react"
import { SmartImageCategorizer } from "./smart-image-categorizer"

interface UploadInterfaceProps {
  onImagesUpdate: (images: File[]) => void
  onMeasurementsUpdate: (measurements: any[]) => void
}

// Upload-Limits definieren
const UPLOAD_LIMITS = {
  maxImages: 50,
  maxFileSize: 15 * 1024 * 1024, // 15MB pro Datei
  maxTotalSize: 200 * 1024 * 1024, // 200MB gesamt
}

export function UploadInterface({ onImagesUpdate, onMeasurementsUpdate }: UploadInterfaceProps) {
  const [uploadedImages, setUploadedImages] = useState<File[]>([])
  const [dragActive, setDragActive] = useState(false)
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({})
  const [uploadErrors, setUploadErrors] = useState<string[]>([])
  const [showCategorizer, setShowCategorizer] = useState(false)

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    const files = Array.from(e.dataTransfer.files).filter((file) => file.type.startsWith("image/"))

    if (files.length > 0) {
      handleFiles(files)
    }
  }, [])

  // Erweiterte Validierungsfunktion
  const validateFiles = (files: File[]): { validFiles: File[]; errors: string[] } => {
    const errors: string[] = []
    const validFiles: File[] = []

    // Prüfe Gesamtanzahl
    if (uploadedImages.length + files.length > UPLOAD_LIMITS.maxImages) {
      errors.push(`Maximale Anzahl von ${UPLOAD_LIMITS.maxImages} Bildern überschritten`)
      return { validFiles: [], errors }
    }

    // Prüfe jede Datei
    files.forEach((file) => {
      // Dateigröße prüfen
      if (file.size > UPLOAD_LIMITS.maxFileSize) {
        errors.push(`${file.name}: Datei zu groß (max. ${UPLOAD_LIMITS.maxFileSize / 1024 / 1024}MB)`)
        return
      }

      // Gesamtgröße prüfen
      const currentTotalSize = uploadedImages.reduce((sum, img) => sum + img.size, 0)
      if (currentTotalSize + file.size > UPLOAD_LIMITS.maxTotalSize) {
        errors.push(`Gesamtgröße überschritten (max. ${UPLOAD_LIMITS.maxTotalSize / 1024 / 1024}MB)`)
        return
      }

      validFiles.push(file)
    })

    return { validFiles, errors }
  }

  const handleFiles = (files: File[]) => {
    const { validFiles, errors } = validateFiles(files)

    if (errors.length > 0) {
      setUploadErrors(errors)
      return
    }

    setUploadErrors([])
    const newImages = [...uploadedImages, ...validFiles]
    setUploadedImages(newImages)
    onImagesUpdate(newImages)

    // Simuliere Upload-Fortschritt
    validFiles.forEach((file) => {
      let progress = 0
      const interval = setInterval(() => {
        progress += 10
        setUploadProgress((prev) => ({ ...prev, [file.name]: progress }))
        if (progress >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            setUploadProgress((prev) => {
              const newProgress = { ...prev }
              delete newProgress[file.name]
              return newProgress
            })
          }, 1000)
        }
      }, 100)
    })

    // Zeige Kategorisierer wenn Bilder vorhanden
    if (newImages.length >= 1) {
      setShowCategorizer(true)
    }
  }

  const removeImage = (index: number) => {
    const newImages = uploadedImages.filter((_, i) => i !== index)
    setUploadedImages(newImages)
    onImagesUpdate(newImages)

    // Verstecke Kategorisierer wenn keine Bilder
    if (newImages.length < 1) {
      setShowCategorizer(false)
    }
  }

  // Berechne Statistiken
  const totalSize = uploadedImages.reduce((sum, img) => sum + img.size, 0)
  const sizePercentage = (totalSize / UPLOAD_LIMITS.maxTotalSize) * 100
  const imagePercentage = (uploadedImages.length / UPLOAD_LIMITS.maxImages) * 100

  return (
    <div className="space-y-6">
      {/* Upload-Statistiken */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="text-lg text-blue-800">Upload-Kapazität</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Bilder</span>
                <span>
                  {uploadedImages.length}/{UPLOAD_LIMITS.maxImages}
                </span>
              </div>
              <Progress value={imagePercentage} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Speicher</span>
                <span>
                  {(totalSize / 1024 / 1024).toFixed(1)}/{UPLOAD_LIMITS.maxTotalSize / 1024 / 1024}MB
                </span>
              </div>
              <Progress value={sizePercentage} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span>Status</span>
                <span>{uploadedImages.length >= 3 ? "Bereit" : "Mehr Bilder"}</span>
              </div>
              <Progress value={uploadedImages.length >= 3 ? 100 : (uploadedImages.length / 3) * 100} className="h-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Fehleranzeige */}
      {uploadErrors.length > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <ul className="list-disc list-inside">
              {uploadErrors.map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      {/* Upload-Bereich */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Bilder hochladen
          </CardTitle>
          <CardDescription>
            Laden Sie Installationsfotos hoch (max. {UPLOAD_LIMITS.maxImages} Bilder,{" "}
            {UPLOAD_LIMITS.maxFileSize / 1024 / 1024}MB pro Datei) - KI-Analyse ab 1 Bild verfügbar
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragActive
                ? "border-blue-500 bg-blue-50"
                : uploadedImages.length >= UPLOAD_LIMITS.maxImages
                  ? "border-red-300 bg-red-50"
                  : "border-gray-300 hover:border-gray-400"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {uploadedImages.length >= UPLOAD_LIMITS.maxImages
                ? "Upload-Limit erreicht"
                : "Bilder hier ablegen oder klicken zum Hochladen"}
            </h3>
            <p className="text-gray-600 mb-4">
              Unterstützt JPG, PNG, HEIC Formate.
              {uploadedImages.length < UPLOAD_LIMITS.maxImages &&
                ` Noch ${UPLOAD_LIMITS.maxImages - uploadedImages.length} Bilder möglich.`}
            </p>
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={(e) => {
                const files = Array.from(e.target.files || [])
                handleFiles(files)
              }}
              className="hidden"
              id="file-upload"
              disabled={uploadedImages.length >= UPLOAD_LIMITS.maxImages}
            />
            <Button asChild disabled={uploadedImages.length >= UPLOAD_LIMITS.maxImages}>
              <label htmlFor="file-upload" className="cursor-pointer">
                <Camera className="h-4 w-4 mr-2" />
                {uploadedImages.length >= UPLOAD_LIMITS.maxImages ? "Limit erreicht" : "Bilder auswählen"}
              </label>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Hochgeladene Bilder */}
      {uploadedImages.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">
              Hochgeladene Bilder ({uploadedImages.length}/{UPLOAD_LIMITS.maxImages})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {uploadedImages.map((file, index) => (
                <div key={index} className="relative group">
                  <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                    <img
                      src={URL.createObjectURL(file) || "/placeholder.svg"}
                      alt={`Upload ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {uploadProgress[file.name] && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-lg">
                      <div className="text-center text-white">
                        <Progress value={uploadProgress[file.name]} className="w-16 mb-2" />
                        <span className="text-xs">{uploadProgress[file.name]}%</span>
                      </div>
                    </div>
                  )}

                  <Button
                    variant="destructive"
                    size="sm"
                    className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6 p-0"
                    onClick={() => removeImage(index)}
                  >
                    <X className="h-3 w-3" />
                  </Button>

                  <div className="mt-1">
                    <p className="text-xs text-gray-600 truncate">{file.name}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Smart Image Categorizer */}
      {showCategorizer && uploadedImages.length > 0 && (
        <SmartImageCategorizer
          images={uploadedImages}
          onCategorizedImagesUpdate={(categorized) => {
            console.log("Kategorisierte Bilder:", categorized)
          }}
          onMeasurementsUpdate={onMeasurementsUpdate}
        />
      )}
    </div>
  )
}
