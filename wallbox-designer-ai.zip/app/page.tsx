"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Camera, FileText, Download, Zap, CheckCircle, Settings } from "lucide-react"
import { UploadInterface } from "@/components/upload-interface"
import { DocumentPreview } from "@/components/document-preview"
import { AIProcessor } from "@/components/ai-processor"
import { installationSteps as definedInstallationSteps } from "@/components/smart-image-categorizer" // Import the steps

interface ProjectData {
  customerName: string
  address: string
  technician: string
  servicePartner: string
  date: string
  wallboxModel: string
  serialNumber: string
  power: string
  images: File[]
  measurements: any[]
  toggleSettings: Record<string, boolean>
  orderNumber: string
  checkedTechnician: string
  categorizedImages: {
    [key: number]: {
      stepName: string
      images: File[]
      confidence: number[]
    }
  }
}

export default function WallboxDesignerAI() {
  const [activeTab, setActiveTab] = useState("upload")
  const [projectData, setProjectData] = useState<ProjectData>({
    customerName: "",
    address: "",
    technician: "",
    servicePartner: "",
    date: new Date().toISOString().split("T")[0],
    wallboxModel: "",
    serialNumber: "",
    power: "22kW",
    images: [],
    measurements: [],
    toggleSettings: {
      DSW1: true,
      DSW2: false,
      Phase1: true,
      Phase2: true,
      Phase3: true,
    },
    orderNumber: "",
    checkedTechnician: "",
    categorizedImages: {},
  })
  const [isProcessing, setIsProcessing] = useState(false)
  const [processingProgress, setProcessingProgress] = useState(0)
  const [documentGenerated, setDocumentGenerated] = useState(false)

  const handleDataUpdate = (field: keyof ProjectData, value: any) => {
    setProjectData((prev) => ({ ...prev, [field]: value }))
  }

  const handleGenerateDocument = async () => {
    setIsProcessing(true)
    setProcessingProgress(0)

    // Simuliere KI-Verarbeitungsschritte
    const steps = [
      "Hochgeladene Bilder werden analysiert...",
      "Messdaten werden extrahiert...",
      "Geräteinformationen werden erkannt...",
      "Dokumentlayout wird generiert...",
      "Dokumentation wird finalisiert...",
    ]

    for (let i = 0; i < steps.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1500))
      setProcessingProgress((i + 1) * 20)
    }

    setIsProcessing(false)
    setDocumentGenerated(true)
    setActiveTab("preview")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        {/* Kopfbereich */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-blue-600 rounded-xl">
              <Zap className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Wallbox Designer KI</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Automatisiertes Tool zur visuellen Dokumentation professioneller Wallbox-Installation
          </p>
          <div className="flex items-center justify-center gap-4 mt-4">
            <Badge variant="secondary" className="px-3 py-1">
              <Camera className="h-4 w-4 mr-1" />
              KI-gestützt
            </Badge>
            <Badge variant="secondary" className="px-3 py-1">
              <FileText className="h-4 w-4 mr-1" />
              Auto-Generierung
            </Badge>
            <Badge variant="secondary" className="px-3 py-1">
              <Download className="h-4 w-4 mr-1" />
              PDF Export
            </Badge>
          </div>
        </div>

        {/* Hauptbenutzeroberfläche */}
        <Card className="max-w-6xl mx-auto shadow-xl">
          <CardHeader className="border-b">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl">Installationsdokumentation</CardTitle>
                <CardDescription>
                  Laden Sie Bilder und Daten hoch, um automatisch professionelle Dokumentation zu erstellen
                </CardDescription>
              </div>
              {documentGenerated && (
                <Badge variant="default" className="bg-green-600">
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Dokument bereit
                </Badge>
              )}
            </div>
          </CardHeader>

          <CardContent className="p-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-4 mb-6">
                <TabsTrigger value="upload" className="flex items-center gap-2">
                  <Upload className="h-4 w-4" />
                  Upload & Eingabe
                </TabsTrigger>
                <TabsTrigger value="process" className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  KI-Verarbeitung
                </TabsTrigger>
                <TabsTrigger value="preview" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Vorschau
                </TabsTrigger>
                <TabsTrigger value="export" className="flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  Export
                </TabsTrigger>
              </TabsList>

              <TabsContent value="upload" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Projektinformationen */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Projektinformationen</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="customer">Kundenname</Label>
                          <Input
                            id="customer"
                            value={projectData.customerName}
                            onChange={(e) => handleDataUpdate("customerName", e.target.value)}
                            placeholder="Kundenname eingeben"
                          />
                        </div>
                        <div>
                          <Label htmlFor="technician">Techniker</Label>
                          <Input
                            id="technician"
                            value={projectData.technician}
                            onChange={(e) => handleDataUpdate("technician", e.target.value)}
                            placeholder="Technikername eingeben"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="address">Installationsadresse</Label>
                        <Textarea
                          id="address"
                          value={projectData.address}
                          onChange={(e) => handleDataUpdate("address", e.target.value)}
                          placeholder="Vollständige Installationsadresse eingeben"
                          rows={2}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="servicePartner">Servicepartner</Label>
                          <Input
                            id="servicePartner"
                            value={projectData.servicePartner}
                            onChange={(e) => handleDataUpdate("servicePartner", e.target.value)}
                            placeholder="Servicepartner-Unternehmen"
                          />
                        </div>
                        <div>
                          <Label htmlFor="date">Installationsdatum</Label>
                          <Input
                            id="date"
                            type="date"
                            value={projectData.date}
                            onChange={(e) => handleDataUpdate("date", e.target.value)}
                          />
                        </div>
                      </div>

                      {/* NEU: Auftragsnummer und Geprüfter Techniker */}
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="orderNumber">Auftragsnummer</Label>
                          <Input
                            id="orderNumber"
                            value={projectData.orderNumber}
                            onChange={(e) => handleDataUpdate("orderNumber", e.target.value)}
                            placeholder="Auftragsnummer eingeben"
                          />
                        </div>
                        <div>
                          <Label htmlFor="checkedTechnician">Geprüfter Techniker</Label>
                          <Input
                            id="checkedTechnician"
                            value={projectData.checkedTechnician}
                            onChange={(e) => handleDataUpdate("checkedTechnician", e.target.value)}
                            placeholder="Name des prüfenden Technikers"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="model">Wallbox-Modell</Label>
                          <Input
                            id="model"
                            value={projectData.wallboxModel}
                            onChange={(e) => handleDataUpdate("wallboxModel", e.target.value)}
                            placeholder="Modellnummer"
                          />
                        </div>
                        <div>
                          <Label htmlFor="serial">Seriennummer</Label>
                          <Input
                            id="serial"
                            value={projectData.serialNumber}
                            onChange={(e) => handleDataUpdate("serialNumber", e.target.value)}
                            placeholder="S/N"
                          />
                        </div>
                        <div>
                          <Label htmlFor="power">Leistung</Label>
                          <Select value={projectData.power} onValueChange={(value) => handleDataUpdate("power", value)}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="11kW">11kW</SelectItem>
                              <SelectItem value="22kW">22kW</SelectItem>
                              <SelectItem value="43kW">43kW</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Gerätekonfiguration */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Gerätekonfiguration</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <Label className="text-sm font-medium mb-3 block">DIP-Schalter Einstellungen</Label>
                          <div className="grid grid-cols-2 gap-3">
                            {Object.entries(projectData.toggleSettings)
                              .slice(0, 2)
                              .map(([key, value]) => (
                                <div key={key} className="flex items-center justify-between p-3 border rounded-lg">
                                  <span className="font-medium">{key}</span>
                                  <Button
                                    variant={value ? "default" : "outline"}
                                    size="sm"
                                    onClick={() =>
                                      handleDataUpdate("toggleSettings", {
                                        ...projectData.toggleSettings,
                                        [key]: !value,
                                      })
                                    }
                                  >
                                    {value ? "EIN" : "AUS"}
                                  </Button>
                                </div>
                              ))}
                          </div>
                        </div>

                        <div>
                          <Label className="text-sm font-medium mb-3 block">Phasenkonfiguration</Label>
                          <div className="grid grid-cols-3 gap-3">
                            {Object.entries(projectData.toggleSettings)
                              .slice(2)
                              .map(([key, value]) => (
                                <div key={key} className="flex items-center justify-between p-3 border rounded-lg">
                                  <span className="font-medium">{key}</span>
                                  <Button
                                    variant={value ? "default" : "outline"}
                                    size="sm"
                                    onClick={() =>
                                      handleDataUpdate("toggleSettings", {
                                        ...projectData.toggleSettings,
                                        [key]: !value,
                                      })
                                    }
                                  >
                                    {value ? "EIN" : "AUS"}
                                  </Button>
                                </div>
                              ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Upload-Schnittstelle */}
                <UploadInterface
                  onImagesUpdate={(images) => handleDataUpdate("images", images)}
                  onMeasurementsUpdate={(measurements) => handleDataUpdate("measurements", measurements)}
                  onCategorizedImagesUpdate={(categorized) => handleDataUpdate("categorizedImages", categorized)}
                />

                <div className="flex justify-end">
                  <Button
                    onClick={handleGenerateDocument}
                    size="lg"
                    className="px-8"
                    disabled={projectData.images.length === 0 || !projectData.customerName}
                  >
                    <Zap className="h-5 w-5 mr-2" />
                    {projectData.images.length > 0
                      ? `Dokumentation aus ${projectData.images.length} Bildern erstellen`
                      : "Dokumentation erstellen"}
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="process">
                <AIProcessor isProcessing={isProcessing} progress={processingProgress} projectData={projectData} />
              </TabsContent>

              <TabsContent value="preview">
                <DocumentPreview
                  projectData={projectData}
                  isGenerated={documentGenerated}
                  installationSteps={definedInstallationSteps} // Pass the defined steps
                />
              </TabsContent>

              <TabsContent value="export">
                <div className="text-center py-12">
                  <div className="max-w-md mx-auto space-y-6">
                    <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                      <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-green-800 mb-2">Dokumentation bereit</h3>
                      <p className="text-green-700">
                        Ihre Wallbox-Installationsdokumentation wurde erfolgreich erstellt.
                      </p>
                    </div>

                    <div className="space-y-3">
                      <Button className="w-full" size="lg">
                        <Download className="h-5 w-5 mr-2" />
                        PDF-Bericht herunterladen
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent" size="lg">
                        <FileText className="h-5 w-5 mr-2" />
                        PowerPoint exportieren
                      </Button>
                      <Button variant="outline" className="w-full bg-transparent" size="lg">
                        <Upload className="h-5 w-5 mr-2" />
                        Ins Backend hochladen
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
