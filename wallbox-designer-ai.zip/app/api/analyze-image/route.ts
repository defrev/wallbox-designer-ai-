import { NextResponse } from "next/server"

// Diese Funktion simuliert eine erweiterte KI-Analyse basierend auf den detaillierten Anforderungen.
// In einer echten Anwendung würde hier die Integration mit einem externen KI-Dienst (z.B. Google Cloud Vision, AWS Rekognition) erfolgen.
async function analyzeImageContent(
  imageName: string,
  imageContentBase64: string, // Simuliert den Bildinhalt für eine tiefere Analyse
): Promise<{ step: number; confidence: number; detectedElements: string[]; ocrText: string[] }> {
  // Eine kleine Verzögerung, um die KI-Verarbeitung zu simulieren
  await new Promise((resolve) => setTimeout(resolve, 500))

  const lowerCaseImageName = imageName.toLowerCase()
  const lowerCaseImageContent = imageContentBase64.toLowerCase() // Für simulierte OCR/Objekterkennung

  // NEU: Simulierte OCR-Texte und Objekte für spezifische Bilder
  // Dies ist eine temporäre Lösung, um die Demo-KI für die bereitgestellten Bilder zu steuern.
  // In einer echten Anwendung würden diese Daten von einem echten OCR/Objekterkennungsdienst kommen.
  const simulatedImageAnalysis: Record<string, { ocr: string[]; objects: string[] }> = {
    "20250205_104429.jpg": {
      ocr: ["H-1", "0.1", "KEBA", "Wallbox", "Charge", "Point"],
      objects: ["wallbox", "display", "charging_cable", "open_top_panel", "screwdriver"],
    },
    "20250205_104539.jpg": {
      ocr: [
        "PROTEC.class",
        "PLPA",
        "L1",
        "L2",
        "L3",
        "CP",
        "PE",
        "N",
        "35.32",
        "kΩ",
        "MODE",
        "PEAK",
        "FUNC",
        "HOLD",
        "AUTO",
        "V",
        "Hz",
        "RCD",
        "MΩ",
        "LAN",
        "A",
        "Ω",
        "AXI",
      ],
      objects: ["measurement_device", "multimeter", "test_adapter", "cables", "display_with_values"],
    },
    "20250205_104439.jpg": {
      ocr: ["PROTEC.class", "PLPA", "L1", "L2", "L3", "CP", "PE", "N", "service", "KEBA", "Wallbox", "Charge", "Point"],
      objects: [
        "measurement_device",
        "test_adapter",
        "wallbox",
        "charging_cable",
        "open_top_panel",
        "screwdriver",
        "display_with_text",
      ],
    },
    "20250205_104532.jpg": {
      ocr: [
        "PROTEC.class",
        "PLPA",
        "L1",
        "L2",
        "L3",
        "CP",
        "PE",
        "N",
        ">1.200",
        "50.0",
        "V",
        "Hz",
        "MODE",
        "PEAK",
        "FUNC",
        "HOLD",
        "AUTO",
        "RCD",
        "MΩ",
        "LAN",
        "A",
        "Ω",
        "AXI",
      ],
      objects: ["measurement_device", "multimeter", "test_adapter", "cables", "display_with_values"],
    },
    "20250205_104552.jpg": {
      ocr: [
        "PROTEC.class",
        "PLPA",
        "L1",
        "L2",
        "L3",
        "CP",
        "PE",
        "N",
        "RCD",
        "225",
        "300",
        "mA",
        "MODE",
        "PEAK",
        "FUNC",
        "HOLD",
        "AUTO",
        "V",
        "Hz",
        "RCD",
        "MΩ",
        "LAN",
        "A",
        "Ω",
        "AXI",
      ],
      objects: ["measurement_device", "multimeter", "test_adapter", "cables", "display_with_values"],
    },
    "20250205_104524.jpg": {
      ocr: [
        "PROTEC.class",
        "PLPA",
        "L1",
        "L2",
        "L3",
        "CP",
        "PE",
        "N",
        "225.0",
        "50.0",
        "V",
        "Hz",
        "MODE",
        "PEAK",
        "FUNC",
        "HOLD",
        "AUTO",
        "RCD",
        "MΩ",
        "LAN",
        "A",
        "Ω",
        "AXI",
      ],
      objects: ["measurement_device", "multimeter", "test_adapter", "cables", "display_with_values"],
    },
  }

  // Kombiniere Dateinamen-Keywords mit simulierten OCR/Objekten für die Analyse
  let combinedAnalysisString = lowerCaseImageName + " " + lowerCaseImageContent
  let detectedOcrText: string[] = []
  let detectedObjects: string[] = []

  const simulatedData = simulatedImageAnalysis[imageName]
  if (simulatedData) {
    combinedAnalysisString += " " + simulatedData.ocr.map((s) => s.toLowerCase()).join(" ")
    combinedAnalysisString += " " + simulatedData.objects.map((s) => s.toLowerCase()).join(" ")
    detectedOcrText = simulatedData.ocr
    detectedObjects = simulatedData.objects
  }

  // Definierte Kategorien mit detaillierten Anforderungen und Ausschlusskriterien
  const categoryDefinitions = {
    1: {
      // Demontage / Vorbereitung
      name: "Demontage / Vorbereitung",
      requirements: [
        (f: string) =>
          (f.includes("wand") && (f.includes("leer") || f.includes("spuren") || f.includes("bohrloch"))) ||
          f.includes("kabelreste"), // Wand ist leer oder zeigt Spuren
        (f: string) =>
          !f.includes("wallbox") && !f.includes("montiert") && !f.includes("gerät") && !f.includes("aktiv"), // Keine aktiven Geräte sichtbar
        (f: string) => f.includes("lose_kabel") || f.includes("offene_anschlussstellen") || f.includes("kabelenden"), // Lose Kabel oder offene Anschlussstellen erkennbar
        (f: string) => f.includes("vor_einbau") || f.includes("vorbereitung"), // Bild zeigt Situation vor dem Einbau
      ],
      exclusion: [
        (f: string) =>
          f.includes("wallbox_montiert") || f.includes("wallbox_installiert") || f.includes("neue_wallbox"), // Aktive Wallbox sichtbar
        (f: string) =>
          f.includes("messgeraet") ||
          f.includes("typenschild") ||
          f.includes("protokoll") ||
          f.includes("protec.class"), // Irrelevante Objekte
      ],
      minRequirements: 3, // Mindestens 3 der 4 Anforderungen müssen erfüllt sein
      baseConfidence: 0.6,
      detectedElements: ["Freiliegende Kabel", "Bohrlöcher", "Leere Wandfläche"],
      ocrText: [],
    },
    2: {
      // Installierte Wallbox
      name: "Wallbox montiert",
      requirements: [
        (f: string) =>
          f.includes("wallbox") && (f.includes("montiert") || f.includes("installiert") || f.includes("angebracht")), // Wallbox an Wand montiert
        (f: string) => f.includes("frontal") || f.includes("leicht_seitlich"), // Frontal oder leicht seitlich aufgenommen
        (f: string) => !f.includes("lose_kabel") && !f.includes("kabel_heraus"), // Keine Kabel lose heraus
        (f: string) => f.includes("logo") || f.includes("seriennummer") || f.includes("hersteller"), // Logo oder Seriennummer lesbar (simuliert)
      ],
      exclusion: [
        (f: string) =>
          f.includes("unscharf") || f.includes("unklar") || f.includes("schief") || f.includes("verwackelt"), // Unklare, unscharfe oder schiefe Bilder
        (f: string) => f.includes("nicht_montiert") || f.includes("liegt_auf_boden"), // Wallbox nicht eindeutig montiert
        (f: string) => f.includes("offen") || f.includes("anschlusskasten"), // Anschlusskasten offen
        (f: string) =>
          f.includes("messgeraet") || f.includes("testgeraet") || f.includes("pruefung") || f.includes("protec.class"), // Messgerät prominent im Bild
      ],
      minRequirements: 3,
      baseConfidence: 0.7,
      detectedElements: ["Wallbox-Gehäuse", "Herstellerlogo", "Ladeanschluss"],
      ocrText: ["22kW", "ChargePoint Pro", "Model: CP-123"],
    },
    3: {
      // Offener Anschlusskasten / Verkabelung
      name: "Offener Anschlusskasten / Verkabelung",
      requirements: [
        (f: string) =>
          f.includes("sicherungskasten") ||
          f.includes("verteilerdose") ||
          f.includes("kasten_offen") ||
          f.includes("wallbox_innenansicht") ||
          f.includes("kabel_einfuehrung"), // Geöffneter Sicherungskasten oder Verteilerdose
        (f: string) =>
          (f.includes("blau") && f.includes("braun") && f.includes("gelb_gruen")) ||
          f.includes("farbcodierte_adern_drei"), // Mindestens drei farbcodierte Adern
        (f: string) => f.includes("klemmen") || f.includes("wago") || f.includes("verbindungen"), // Klemmen, WAGO-Verbinder oder Verbindungen sichtbar
        (f: string) => !f.includes("messgeraet") && !f.includes("haupt_typenschild") && !f.includes("protec.class"), // Keine Messgeräte, keine Geräteetiketten
      ],
      exclusion: [
        (f: string) => f.includes("unklarer_fokus") || f.includes("nur_einzelnes_kabel"), // Unklarer Fokus oder nur einzelne Kabel
        (f: string) => f.includes("geschlossen") || f.includes("deckel_drauf"), // Kasten geschlossen
        (f: string) => f.includes("wallbox") || f.includes("typenschild"), // Wallbox oder Typenschild im Bild
        (f: string) =>
          f.includes("messgeraet") || f.includes("testgeraet") || f.includes("pruefung") || f.includes("protec.class"), // Messgerät prominent im Bild
      ],
      minRequirements: 3,
      baseConfidence: 0.65,
      detectedElements: ["Sicherungskasten", "WAGO-Klemmen", "Phasenkabel"],
      ocrText: ["L1", "L2", "L3", "N", "PE"],
    },
    4: {
      // Sicherungsbeschriftung (NEU in 9-Schritte-Struktur)
      name: "Sicherungsbeschriftung",
      requirements: [
        (f: string) => f.includes("sicherung") || f.includes("ls_schalter") || f.includes("beschriftung"),
        (f: string) => f.includes("text_lesbar") || f.includes("nummern") || f.includes("symbole"),
        (f: string) => f.includes("nahaufnahme") || f.includes("fokus_auf_beschriftung"),
      ],
      exclusion: [
        (f: string) => f.includes("unscharf") || f.includes("unleserlich"),
        (f: string) =>
          f.includes("messgeraet") ||
          f.includes("typenschild") ||
          f.includes("protokoll") ||
          f.includes("protec.class"),
      ],
      minRequirements: 2,
      baseConfidence: 0.8,
      detectedElements: ["Sicherungsautomat", "Beschriftungsfeld", "Text/Symbole"],
      ocrText: ["C16", "B20", "32A", "LS", "FI"],
    },
    5: {
      // Phasenschaltung (DSW-Schalter) - Jetzt Schritt 5
      name: "Phasenschaltung (DSW-Schalter)",
      requirements: [
        (f: string) =>
          f.includes("dsw_1") ||
          f.includes("dsw_2") ||
          f.includes("1-5_off") ||
          f.includes("6+7+8_on") ||
          f.includes("schaltzustaende"), // Text wie „DSW 1“, „DSW 2“, „1-5 OFF“, „6+7+8 ON“ sichtbar
        (f: string) => f.includes("schaltplan") || f.includes("bildschirmfoto") || f.includes("physisches_panel"), // Schaltplan, Bildschirmfoto oder physisches Panel
        (f: string) => f.includes("tabelle") || f.includes("matrix") || f.includes("phaseneinstellungen_klar"), // Phaseinstellungen klar als Tabelle oder Matrix erkennbar
      ],
      exclusion: [
        (f: string) => !f.includes("on_off") || f.includes("nur_dsw_text"), // Ohne ON/OFF-Angaben oder nur „DSW“-Text
        (f: string) => f.includes("unscharf") || f.includes("unleserlich"), // Unleserlich
        (f: string) =>
          f.includes("messgeraet") ||
          f.includes("typenschild") ||
          f.includes("protokoll") ||
          f.includes("protec.class"), // Irrelevante Objekte
      ],
      minRequirements: 2,
      baseConfidence: 0.8,
      detectedElements: ["DIP-Schalter", "Schaltplan-Aufkleber", "LED-Anzeigen"],
      ocrText: ["DSW1: ON", "DSW2: OFF", "Phase 1-3"],
    },
    6: {
      // Messung / Testgerät - Jetzt Schritt 6
      name: "Messung / Testgerät",
      requirements: [
        (f: string) =>
          f.includes("messgeraet") ||
          f.includes("testgeraet") ||
          f.includes("digitalanzeige") ||
          f.includes("installationstester") ||
          f.includes("orange_schwarz_geraet") ||
          f.includes("drehschalter") ||
          f.includes("protec.class") ||
          f.includes("plpa") ||
          f.includes("l1_l2_l3_lights") ||
          f.includes("multimeter") ||
          f.includes("test_adapter"),
        (f: string) =>
          f.includes("werte_sichtbar") ||
          f.includes("230_v") ||
          f.includes("400_v") ||
          f.includes("50_hz") ||
          f.includes("0_34_ohm") ||
          f.includes("rcd_test") ||
          f.includes("loop") ||
          f.includes("insulation") ||
          f.includes("ms") ||
          f.includes("ma") ||
          f.includes("kohm") ||
          f.includes("ohm") ||
          f.includes("axi") ||
          f.includes("35.32") ||
          f.includes("225.0") ||
          f.includes("300"),
        (f: string) =>
          f.includes("messleitungen") ||
          f.includes("rot_schwarz_kabel") ||
          f.includes("gruen_kabel") ||
          f.includes("test_plug") ||
          f.includes("angeschlossen") ||
          f.includes("cables"),
        (f: string) =>
          f.includes("display_klar") ||
          f.includes("display_vollstaendig") ||
          f.includes("display_lesbar") ||
          f.includes("display_with_values"),
        (f: string) =>
          f.includes("offener_anschlusskasten") ||
          f.includes("wallbox_anschluss") ||
          f.includes("kabel_angeschlossen") ||
          f.includes("test_setup") ||
          f.includes("pruefung_laeuft"),
      ],
      exclusion: [
        (f: string) =>
          f.includes("unscharf") ||
          f.includes("unvollstaendig") ||
          f.includes("nicht_lesbar") ||
          f.includes("keine_werte_display"),
        (f: string) => f.includes("wallbox_ohne_messgeraet") || f.includes("sicherungskasten_ohne_messgeraet"),
        (f: string) => f.includes("typenschild") || f.includes("protokoll") || f.includes("formular"),
        (f: string) => f.includes("nur_kabel") || f.includes("nur_wand"),
      ],
      minRequirements: 4,
      baseConfidence: 0.9,
      detectedElements: [
        "Digital-Display",
        "Messleitungen",
        "Messwerte",
        "PROTEC.class Tester",
        "Multimeter",
        "Testadapter",
      ],
      ocrText: [
        "230V",
        "400V",
        "32A",
        "0.5Ω",
        "PASS",
        "RCD",
        "ms",
        "mA",
        "Hz",
        "AXI",
        "PROTEC.class",
        "PLPA",
        "kΩ",
        "Ω",
        "35.32",
        "225.0",
        "300",
        "L1",
        "L2",
        "L3",
        "CP",
        "PE",
        "N",
        "MODE",
        "PEAK",
        "FUNC",
        "HOLD",
        "AUTO",
        "V",
        "Hz",
        "MΩ",
        "LAN",
        "A",
      ],
    },
    7: {
      // Backend-Freischaltung / Systembestätigung - Jetzt Schritt 7
      name: "Backend-Freischaltung / Systembestätigung",
      requirements: [
        (f: string) =>
          f.includes("bildschirm") ||
          f.includes("software") ||
          f.includes("app_oberflaeche") ||
          f.includes("wallbox_display"),
        (f: string) =>
          f.includes("backend_bestaetigt") ||
          f.includes("aktiv") ||
          f.includes("bereit") ||
          f.includes("uhrzeit_sichtbar") ||
          f.includes("akzept") ||
          f.includes("halten") ||
          f.includes("charg") ||
          f.includes("km") ||
          f.includes("prozent") ||
          f.includes("kw") ||
          f.includes("fahrzeug_display") ||
          f.includes("service_display") ||
          f.includes("h-1") ||
          f.includes("0.1"),
        (f: string) =>
          f.includes("ui_elemente") ||
          f.includes("buttons") ||
          f.includes("menues") ||
          f.includes("statusanzeigen") ||
          f.includes("display_with_text"),
      ],
      exclusion: [
        (f: string) => !f.includes("bestaetigung") || !f.includes("systemstatus"),
        (f: string) => f.includes("startbildschirm") || f.includes("app_menue_nur"),
        (f: string) =>
          f.includes("messgeraet") ||
          f.includes("typenschild") ||
          f.includes("protokoll") ||
          f.includes("protec.class"),
      ],
      minRequirements: 2,
      baseConfidence: 0.7,
      detectedElements: [
        "Smartphone-Display",
        "Backend-Interface",
        "Zeitstempel",
        "Fahrzeug-Display",
        "Wallbox-Display",
      ],
      ocrText: [
        "Backend OK",
        "14:32",
        "Status: Aktiv",
        "Akzept",
        "halten",
        "+Charg",
        "km",
        "%",
        "kW",
        "service",
        "H-1",
        "0.1",
      ],
    },
    8: {
      // Typenschild / Seriennummer - Jetzt Schritt 8
      name: "Typenschild / Seriennummer",
      requirements: [
        (f: string) => f.includes("typenschild") || f.includes("aufkleber_geraet"),
        (f: string) =>
          f.includes("s_n") ||
          f.includes("serial_number") ||
          f.includes("model") ||
          f.includes("22_kw") ||
          f.includes("typ"),
        (f: string) => f.includes("vollstaendig_im_bild") || f.includes("gut_lesbar"),
      ],
      exclusion: [
        (f: string) => f.includes("verschwommen") || f.includes("abgeschnitten") || f.includes("nicht_zuordenbar"),
        (f: string) => f.includes("allgemeine_textaufkleber") || f.includes("werbung"),
        (f: string) =>
          f.includes("messgeraet") ||
          f.includes("protokoll") ||
          f.includes("sicherungskasten") ||
          f.includes("protec.class"),
      ],
      minRequirements: 3,
      baseConfidence: 0.85,
      detectedElements: ["Typenschild", "Seriennummer", "CE-Kennzeichnung"],
      ocrText: ["S/N: WB240001", "22kW", "Made in Germany"],
    },
    9: {
      // Abnahmeprotokoll / Unterschrift - Jetzt Schritt 9
      name: "Abnahmeprotokoll / Unterschrift",
      requirements: [
        (f: string) =>
          f.includes("formular_felder") || f.includes("name_datum_unterschrift") || f.includes("status_sichtbar"),
        (f: string) => f.includes("ausgefuellt") || f.includes("teilausgefuellt"),
        (f: string) => f.includes("handschrift") || f.includes("digitale_unterschrift"),
      ],
      exclusion: [
        (f: string) => f.includes("blankoformular") || f.includes("werbebroschuere") || f.includes("datenblatt"),
        (f: string) => f.includes("text_zu_klein") || f.includes("unleserlich_text"),
        (f: string) =>
          f.includes("wallbox") ||
          f.includes("messgeraet") ||
          f.includes("sicherungskasten") ||
          f.includes("protec.class"),
      ],
      minRequirements: 2,
      baseConfidence: 0.78,
      detectedElements: ["Unterschriftenfeld", "Formular-Layout", "Datum/Zeit"],
      ocrText: ["Techniker:", "Datum:", "Unterschrift:"],
    },
  }

  let bestMatch = { step: 0, confidence: 0, detectedElements: [], ocrText: [] }

  for (const stepNumStr in categoryDefinitions) {
    const stepNum = Number.parseInt(stepNumStr)
    const def = categoryDefinitions[stepNum as keyof typeof categoryDefinitions]

    let isExcluded = false
    for (const excludeFn of def.exclusion) {
      // Prüfe sowohl den kombinierten String als auch die simulierten Objekte
      if (excludeFn(combinedAnalysisString) || detectedObjects.some((obj) => excludeFn(obj))) {
        isExcluded = true
        break
      }
    }

    if (isExcluded) {
      continue // Diese Kategorie überspringen, wenn Ausschlusskriterium erfüllt
    }

    let metRequirementsCount = 0
    for (const reqFn of def.requirements) {
      // Prüfe sowohl den kombinierten String als auch die simulierten Objekte
      if (reqFn(combinedAnalysisString) || detectedObjects.some((obj) => reqFn(obj))) {
        metRequirementsCount++
      }
    }

    // Nur wenn die Mindestanforderungen erfüllt sind, wird die Konfidenz berechnet
    if (metRequirementsCount >= def.minRequirements) {
      let currentConfidence =
        def.baseConfidence + (metRequirementsCount / def.requirements.length) * (1 - def.baseConfidence)
      currentConfidence = Math.min(currentConfidence, 0.99) // Max 99%

      if (currentConfidence > bestMatch.confidence) {
        bestMatch = {
          step: stepNum,
          confidence: currentConfidence,
          detectedElements: def.detectedElements,
          ocrText: def.ocrText,
        }
      }
    }
  }

  // Wenn kein Schritt mit ausreichender Konfidenz zugeordnet werden konnte,
  // oder wenn es sich um ein "unbekanntes/irrelevantes" Bild handelt (impliziert durch keine Übereinstimmung),
  // wird es als Schritt 0 (gefiltert) zurückgegeben.
  if (bestMatch.step === 0 || bestMatch.confidence < 0.6) {
    // Mindestkonfidenz für Zuordnung
    return { step: 0, confidence: 0, detectedElements: [], ocrText: [] }
  }

  return bestMatch
}

export async function POST(request: Request) {
  try {
    const { imageName, imageBase64 } = await request.json()

    if (!imageName || !imageBase64) {
      return NextResponse.json({ error: "Image name and base64 content are required." }, { status: 400 })
    }

    const result = await analyzeImageContent(imageName, imageBase64)

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error analyzing image:", error)
    return NextResponse.json({ error: "Failed to analyze image." }, { status: 500 })
  }
}
